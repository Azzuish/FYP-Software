function package = Loop_Calc(Table);

B = Table.B_Loop;
H = Table.H_Loop;

Loop_Area = polyarea(H, B);

Bs = max(B);

%Find Br
zero_crossings_H = find(H(1:end-1) .* H(2:end) < 0);

max_cross = 0;

max_index = 0;

Br_list = zeros(size(zero_crossings_H));
for k = 1:length(zero_crossings_H)
    i = zero_crossings_H(k);
    % Linear interpolation for B at H = 0
    Br_list(k) = interp1(H(i:i+1), B(i:i+1), 0);
    if Br_list(k) > max_cross
        max_cross = Br_list(k);
        max_index = zero_crossings_H(k);
    end
end

Br = max(abs(Br_list));

% Find Hc
zero_crossings = find(B(1:end-1) .* B(2:end) < 0);

Hc_list = zeros(size(zero_crossings));
for k = 1:length(zero_crossings)
    i = zero_crossings(k);
    Hc_list(k) = interp1(B(i:i+1), H(i:i+1), 0);
end

% Pick positive Hc
Hc = max(abs(Hc_list));

window_radius = 5; 
left_seg = max (max_index - window_radius, 1);
right_seg = min(max_index + window_radius, length(H));

H_seg = H(left_seg:right_seg);
B_seg = B(left_seg:right_seg);

grad_find = polyfit(H_seg, B_seg, 1);

mu = grad_find(1);
mu_0 = 4 * pi * 10^(-7);
mu_r = mu/mu_0;

package.Area = Loop_Area;
package.B_sat = Bs;
package.B_rem = Br;
package.H_coe = Hc;
package.Mu_rel = mu_r;

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Fillet Open
Fillet_Pow = readtable('Filleted_RMS.xlsx');
Fillet_10_300 = readtable('Fillet_BH_10.0A_300.csv');
Fillet_10_500 = readtable('Fillet_BH_10.0A_500.csv');
Fillet_10_800 = readtable('Fillet_BH_10.0A_800.csv');
Fillet_10_1000 = readtable('Fillet_BH_10.0A_1000.csv');
Fillet_7_300 = readtable('Fillet_BH_7.0A_300.csv');
Fillet_8_300 = readtable('Fillet_BH_8.0A_300.csv');
Fillet_9_300 = readtable('Fillet_BH_9.0A_300.csv');
Fillet_12_300 = readtable('Fillet_BH_12.0A_300.csv');

Pack_Fillet_10_300 = Loop_Calc(Fillet_10_300);

% W2.5 Open
W2_5_Pow = readtable('W2.5_RMS.xlsx');
W2_5_10_300 = readtable('W2.5_BH_10.0A_300.csv');
W2_5_10_500 = readtable('W2.5_BH_10.0A_500.csv');
W2_5_10_800 = readtable('W2.5_BH_10.0A_800.csv');
W2_5_10_1000 = readtable('W2.5_BH_10.0A_1000.csv');
W2_5_7_300 = readtable('W2.5_BH_7.0A_300.csv');
W2_5_8_300 = readtable('W2.5_BH_8.0A_300.csv');
W2_5_9_300 = readtable('W2.5_BH_9.0A_300.csv');
W2_5_12_300 = readtable('W2.5_BH_12.0A_300.csv');

Pack_W2_5_10_300 = Loop_Calc(W2_5_10_300);

% W5 Open
W5_Pow = readtable('W5_RMS.xlsx');
W5_10_300 = readtable('W5_BH_10.0A_300.csv');
W5_10_500 = readtable('W5_BH_10.0A_500.csv');
W5_10_800 = readtable('W5_BH_10.0A_800.csv');
W5_10_1000 = readtable('W5_BH_10.0A_1000.csv');
W5_7_300 = readtable('W5_BH_7.0A_300.csv');
W5_8_300 = readtable('W5_BH_8.0A_300.csv');
W5_9_300 = readtable('W5_BH_9.0A_300.csv');
W5_12_300 = readtable('W5_BH_12.0A_300.csv');

Pack_W5_10_300 = Loop_Calc(W5_10_300);

% W7.5 Open
W7_5_Pow = readtable('W7.5_RMS.xlsx');
W7_5_10_300 = readtable('W7.5_BH_10.0A_300.csv');
W7_5_10_500 = readtable('W7.5_BH_10.0A_500.csv');
W7_5_10_800 = readtable('W7.5_BH_10.0A_800.csv');
W7_5_10_1000 = readtable('W7.5_BH_10.0A_1000.csv');
W7_5_7_300 = readtable('W7.5_BH_7.0A_300.csv');
W7_5_8_300 = readtable('W7.5_BH_8.0A_300.csv');
W7_5_9_300 = readtable('W7.5_BH_9.0A_300.csv');
W7_5_12_300 = readtable('W7.5_BH_12.0A_300.csv');

Pack_W7_5_10_300 = Loop_Calc(W7_5_10_300);

% W10 Open
W10_Pow = readtable('W10_RMS.xlsx');
W10_10_300 = readtable('W10_BH_10.0A_300.csv');
W10_10_500 = readtable('W10_BH_10.0A_500.csv');
W10_10_800 = readtable('W10_BH_10.0A_800.csv');
W10_10_1000 = readtable('W10_BH_10.0A_1000.csv');
W10_7_300 = readtable('W10_BH_7.0A_300.csv');
W10_8_300 = readtable('W10_BH_8.0A_300.csv');
W10_9_300 = readtable('W10_BH_9.0A_300.csv');
W10_12_300 = readtable('W10_BH_12.0A_300.csv');

Pack_W10_10_300 = Loop_Calc(W10_10_300);

% W12.5 Open
W12_5_Pow = readtable('W12.5_RMS.xlsx');
W12_5_10_300 = readtable('W12.5_BH_10.0A_300.csv');
W12_5_10_500 = readtable('W12.5_BH_10.0A_500.csv');
W12_5_10_800 = readtable('W12.5_BH_10.0A_800.csv');
W12_5_10_1000 = readtable('W12.5_BH_10.0A_1000.csv');
W12_5_7_300 = readtable('W12.5_BH_7.0A_300.csv');
W12_5_8_300 = readtable('W12.5_BH_8.0A_300.csv');
W12_5_9_300 = readtable('W12.5_BH_9.0A_300.csv');
W12_5_12_300 = readtable('W12.5_BH_12.0A_300.csv');

Pack_W12_5_10_300 = Loop_Calc(W12_5_10_300);

% Smooth Open
Smooth_Pow = readtable('Smooth_RMS.xlsx');
Smooth_10_300 = readtable('Smooth_BH_10.0A_300.csv');
Smooth_10_500 = readtable('Smooth_BH_10.0A_500.csv');
Smooth_10_800 = readtable('Smooth_BH_10.0A_800.csv');
Smooth_10_1000 = readtable('Smooth_BH_10.0A_1000.csv');
Smooth_7_300 = readtable('Smooth_BH_7.0A_300.csv');
Smooth_8_300 = readtable('Smooth_BH_8.0A_300.csv');
Smooth_9_300 = readtable('Smooth_BH_9.0A_300.csv');
Smooth_12_300 = readtable('Smooth_BH_12.0A_300.csv');

Pack_Smooth_10_300 = Loop_Calc(Smooth_10_300);

% Trapezoidal Open
Trapezoidal_Pow = readtable('Trapezoidal_RMS.xlsx');
Trapezoidal_10_300 = readtable('Trapezoidal_BH_10.0A_300.csv');
Trapezoidal_10_500 = readtable('Trapezoidal_BH_10.0A_500.csv');
Trapezoidal_10_800 = readtable('Trapezoidal_BH_10.0A_800.csv');
Trapezoidal_10_1000 = readtable('Trapezoidal_BH_10.0A_1000.csv');
Trapezoidal_7_300 = readtable('Trapezoidal_BH_7.0A_300.csv');
Trapezoidal_8_300 = readtable('Trapezoidal_BH_8.0A_300.csv');
Trapezoidal_9_300 = readtable('Trapezoidal_BH_9.0A_300.csv');
Trapezoidal_12_300 = readtable('Trapezoidal_BH_12.0A_300.csv');

Pack_Trapezoidal_10_300 = Loop_Calc(Trapezoidal_10_300);

% L5 Open
L5_Pow = readtable('L5_RMS.xlsx');
L5_10_300 = readtable('L5_BH_10.0A_300.csv');
L5_10_500 = readtable('L5_BH_10.0A_500.csv');
L5_10_800 = readtable('L5_BH_10.0A_800.csv');
L5_10_1000 = readtable('L5_BH_10.0A_1000.csv');
L5_7_300 = readtable('L5_BH_7.0A_300.csv');
L5_8_300 = readtable('L5_BH_8.0A_300.csv');
L5_9_300 = readtable('L5_BH_9.0A_300.csv');
L5_12_300 = readtable('L5_BH_12.0A_300.csv');

Pack_L5_10_300 = Loop_Calc(L5_10_300);

% L10 Open
L10_Pow = readtable('L10_RMS.xlsx');
L10_10_300 = readtable('L10_BH_10.0A_300.csv');
L10_10_500 = readtable('L10_BH_10.0A_500.csv');
L10_10_800 = readtable('L10_BH_10.0A_800.csv');
L10_10_1000 = readtable('L10_BH_10.0A_1000.csv');
L10_7_300 = readtable('L10_BH_7.0A_300.csv');
L10_8_300 = readtable('L10_BH_8.0A_300.csv');
L10_9_300 = readtable('L10_BH_9.0A_300.csv');
L10_12_300 = readtable('L10_BH_12.0A_300.csv');

Pack_L10_8_300 = Loop_Calc(L10_8_300);
Pack_L10_9_300 = Loop_Calc(L10_9_300);
Pack_L10_10_300 = Loop_Calc(L10_10_300);

% L15 Open
L15_Pow = readtable('L15_RMS.xlsx');
L15_10_300 = readtable('L15_BH_10.0A_300.csv');
L15_10_500 = readtable('L15_BH_10.0A_500.csv');
L15_10_800 = readtable('L15_BH_10.0A_800.csv');
L15_10_1000 = readtable('L15_BH_10.0A_1000.csv');
L15_7_300 = readtable('L15_BH_7.0A_300.csv');
L15_8_300 = readtable('L15_BH_8.0A_300.csv');
L15_9_300 = readtable('L15_BH_9.0A_300.csv');
L15_12_300 = readtable('L15_BH_12.0A_300.csv');

Pack_L15_10_300 = Loop_Calc(L15_10_300);

% L20 Open
L20_Pow = readtable('L20_RMS.xlsx');
L20_10_300 = readtable('L20_BH_10.0A_300.csv');
L20_10_500 = readtable('L20_BH_10.0A_500.csv');
L20_10_800 = readtable('L20_BH_10.0A_800.csv');
L20_10_1000 = readtable('L20_BH_10.0A_1000.csv');
L20_7_300 = readtable('L20_BH_7.0A_300.csv');
L20_8_300 = readtable('L20_BH_8.0A_300.csv');
L20_9_300 = readtable('L20_BH_9.0A_300.csv');
L20_12_300 = readtable('L20_BH_12.0A_300.csv');

Pack_L20_10_300 = Loop_Calc(L20_10_300);

% L25 Open
L25_Pow = readtable('L25_RMS.xlsx');
L25_10_300 = readtable('L25_BH_10.0A_300.csv');
L25_10_500 = readtable('L25_BH_10.0A_500.csv');
L25_10_800 = readtable('L25_BH_10.0A_800.csv');
L25_10_1000 = readtable('L25_BH_10.0A_1000.csv');
L25_7_300 = readtable('L25_BH_7.0A_300.csv');
L25_8_300 = readtable('L25_BH_8.0A_300.csv');
L25_9_300 = readtable('L25_BH_9.0A_300.csv');
L25_12_300 = readtable('L25_BH_12.0A_300.csv');

Pack_L25_10_300 = Loop_Calc(L25_10_300);

% FL10 Open
FL10_Pow = readtable('FL10_RMS.xlsx');
FL10_10_300 = readtable('FL10_BH_10.0A_300.csv');
FL10_10_500 = readtable('FL10_BH_10.0A_500.csv');
FL10_10_800 = readtable('FL10_BH_10.0A_800.csv');
FL10_10_1000 = readtable('FL10_BH_10.0A_1000.csv');
FL10_7_300 = readtable('FL10_BH_7.0A_300.csv');
FL10_8_300 = readtable('FL10_BH_8.0A_300.csv');
FL10_9_300 = readtable('FL10_BH_9.0A_300.csv');
FL10_12_300 = readtable('FL10_BH_12.0A_300.csv');

Pack_FL10_10_300 = Loop_Calc(FL10_10_300);

% FL20 Open
FL20_Pow = readtable('FL20_RMS.xlsx');
FL20_10_300 = readtable('FL20_BH_10.0A_300.csv');
FL20_10_500 = readtable('FL20_BH_10.0A_500.csv');
FL20_10_800 = readtable('FL20_BH_10.0A_800.csv');
FL20_10_1000 = readtable('FL20_BH_10.0A_1000.csv');
FL20_7_300 = readtable('FL20_BH_7.0A_300.csv');
FL20_8_300 = readtable('FL20_BH_8.0A_300.csv');
FL20_9_300 = readtable('FL20_BH_9.0A_300.csv');
FL20_12_300 = readtable('FL20_BH_12.0A_300.csv');

Pack_FL20_10_300 = Loop_Calc(FL20_10_300);

% FL30 Open
FL30_Pow = readtable('FL30_RMS.xlsx');
FL30_10_300 = readtable('FL30_BH_10.0A_300.csv');
FL30_10_500 = readtable('FL30_BH_10.0A_500.csv');
FL30_10_800 = readtable('FL30_BH_10.0A_800.csv');
FL30_10_1000 = readtable('FL30_BH_10.0A_1000.csv');
FL30_7_300 = readtable('FL30_BH_7.0A_300.csv');
FL30_8_300 = readtable('FL30_BH_8.0A_300.csv');
FL30_9_300 = readtable('FL30_BH_9.0A_300.csv');
FL30_12_300 = readtable('FL30_BH_12.0A_300.csv');

Pack_FL30_10_300 = Loop_Calc(FL30_10_300);

% FL40 Open
FL40_Pow = readtable('FL40_RMS.xlsx');
FL40_10_300 = readtable('FL40_BH_10.0A_300.csv');
FL40_10_500 = readtable('FL40_BH_10.0A_500.csv');
FL40_10_800 = readtable('FL40_BH_10.0A_800.csv');
FL40_10_1000 = readtable('FL40_BH_10.0A_1000.csv');
FL40_7_300 = readtable('FL40_BH_7.0A_300.csv');
FL40_8_300 = readtable('FL40_BH_8.0A_300.csv');
FL40_9_300 = readtable('FL40_BH_9.0A_300.csv');
FL40_12_300 = readtable('FL40_BH_12.0A_300.csv');

Pack_FL40_10_300 = Loop_Calc(FL40_10_300);

% FL50 Open
FL50_Pow = readtable('FL50_RMS.xlsx');
FL50_10_300 = readtable('FL50_BH_10.0A_300.csv');
FL50_10_500 = readtable('FL50_BH_10.0A_500.csv');
FL50_10_800 = readtable('FL50_BH_10.0A_800.csv');
FL50_10_1000 = readtable('FL50_BH_10.0A_1000.csv');
FL50_7_300 = readtable('FL50_BH_7.0A_300.csv');
FL50_8_300 = readtable('FL50_BH_8.0A_300.csv');
FL50_9_300 = readtable('FL50_BH_9.0A_300.csv');
FL50_12_300 = readtable('FL50_BH_12.0A_300.csv');

Pack_FL50_10_300 = Loop_Calc(FL50_10_300);

% Moulded Basic Open
Moulded_Basic_Pow = readtable('Moulded_Basic_RMS.xlsx');
Moulded_Basic_10_300 = readtable('Moulded Basic_BH_10.0A_300.csv');
Moulded_Basic_10_500 = readtable('Moulded Basic_BH_10.0A_500.csv');
Moulded_Basic_10_800 = readtable('Moulded Basic_BH_10.0A_800.csv');
Moulded_Basic_10_1000 = readtable('Moulded Basic_BH_10.0A_1000.csv');
Moulded_Basic_7_300 = readtable('Moulded Basic_BH_7.0A_300.csv');
Moulded_Basic_8_300 = readtable('Moulded Basic_BH_8.0A_300.csv');
Moulded_Basic_9_300 = readtable('Moulded Basic_BH_9.0A_300.csv');
Moulded_Basic_12_300 = readtable('Moulded Basic_BH_12.0A_300.csv');

Pack_Moulded_Basic_7_300 = Loop_Calc(Moulded_Basic_7_300);
Pack_Moulded_Basic_8_300 = Loop_Calc(Moulded_Basic_8_300);
Pack_Moulded_Basic_9_300 = Loop_Calc(Moulded_Basic_9_300);
Pack_Moulded_Basic_10_300 = Loop_Calc(Moulded_Basic_10_300);
Pack_Moulded_Basic_12_300 = Loop_Calc(Moulded_Basic_12_300);

% MIT Basic Open
MIT_Basic_Pow = readtable('MIT_Basic_RMS.xlsx');
MIT_Basic_10_300 = readtable('MIT Basic_BH_10.0A_300.csv');
MIT_Basic_10_500 = readtable('MIT Basic_BH_10.0A_500.csv');
MIT_Basic_10_800 = readtable('MIT Basic_BH_10.0A_800.csv');
MIT_Basic_10_1000 = readtable('MIT Basic_BH_10.0A_1000.csv');
MIT_Basic_7_300 = readtable('MIT Basic_BH_7.0A_300.csv');
MIT_Basic_8_300 = readtable('MIT Basic_BH_8.0A_300.csv');
MIT_Basic_9_300 = readtable('MIT Basic_BH_9.0A_300.csv');
MIT_Basic_12_300 = readtable('MIT Basic_BH_12.0A_300.csv');

Pack_MIT_Basic_7_300 = Loop_Calc(MIT_Basic_7_300);
Pack_MIT_Basic_8_300 = Loop_Calc(MIT_Basic_8_300);
Pack_MIT_Basic_9_300 = Loop_Calc(MIT_Basic_9_300);
Pack_MIT_Basic_10_300 = Loop_Calc(MIT_Basic_10_300);
Pack_MIT_Basic_12_300 = Loop_Calc(MIT_Basic_12_300);

% MnZn Basic Open
MnZn_Basic_Pow = readtable('MnZn_Basic_RMS.xlsx');
MnZn_Basic_10_300 = readtable('MnZn Ferrite Basic_BH_10.0A_300.csv');
MnZn_Basic_10_500 = readtable('MnZn Ferrite Basic_BH_10.0A_500.csv');
MnZn_Basic_10_800 = readtable('MnZn Ferrite Basic_BH_10.0A_800.csv');
MnZn_Basic_10_1000 = readtable('MnZn Ferrite Basic_BH_10.0A_1000.csv');
MnZn_Basic_7_300 = readtable('MnZn Ferrite Basic_BH_7.0A_300.csv');
MnZn_Basic_8_300 = readtable('MnZn Ferrite Basic_BH_8.0A_300.csv');
MnZn_Basic_9_300 = readtable('MnZn Ferrite Basic_BH_9.0A_300.csv');
MnZn_Basic_12_300 = readtable('MnZn Ferrite Basic_BH_12.0A_300.csv');

Pack_MnZn_Basic_7_300 = Loop_Calc(MnZn_Basic_7_300);
Pack_MnZn_Basic_8_300 = Loop_Calc(MnZn_Basic_8_300);
Pack_MnZn_Basic_9_300 = Loop_Calc(MnZn_Basic_9_300);
Pack_MnZn_Basic_10_300 = Loop_Calc(MnZn_Basic_10_300);
Pack_MnZn_Basic_12_300 = Loop_Calc(MnZn_Basic_12_300);

% PP 30 C Open
PP_30C_Pow = readtable('PP_30 C.xlsx');
PP_30C_10_300 = readtable('Protopasta 30 C_BH_10.0A_300.csv');
PP_30C_10_500 = readtable('Protopasta 30 C_BH_10.0A_500.csv');
PP_30C_10_800 = readtable('Protopasta 30 C_BH_10.0A_800.csv');
PP_30C_10_1000 = readtable('Protopasta 30 C_BH_10.0A_1000.csv');
PP_30C_7_300 = readtable('Protopasta 30 C_BH_7.0A_300.csv');
PP_30C_8_300 = readtable('Protopasta 30 C_BH_8.0A_300.csv');
PP_30C_9_300 = readtable('Protopasta 30 C_BH_9.0A_300.csv');
PP_30C_12_300 = readtable('Protopasta 30 C_BH_12.0A_300.csv');

Pack_PP_30C_10_300 = Loop_Calc(PP_30C_10_300);

% Moulded 30 C Open
Moulded_30C_Pow = readtable('Moulded_30 C.xlsx');
Moulded_30C_10_300 = readtable('Moulded 30 C_BH_10.0A_300.csv');
Moulded_30C_10_500 = readtable('Moulded 30 C_BH_10.0A_500.csv');
Moulded_30C_10_800 = readtable('Moulded 30 C_BH_10.0A_800.csv');
Moulded_30C_10_1000 = readtable('Moulded 30 C_BH_10.0A_1000.csv');
Moulded_30C_7_300 = readtable('Moulded 30 C_BH_7.0A_300.csv');
Moulded_30C_8_300 = readtable('Moulded 30 C_BH_8.0A_300.csv');
Moulded_30C_9_300 = readtable('Moulded 30 C_BH_9.0A_300.csv');
Moulded_30C_12_300 = readtable('Moulded 30 C_BH_12.0A_300.csv');

Pack_Moulded_30C_10_300 = Loop_Calc(Moulded_30C_10_300);

% MIT 30 C Open
MIT_30C_Pow = readtable('MIT_30 C.xlsx');
MIT_30C_10_300 = readtable('MIT 3D Print 30 C_BH_10.0A_300.csv');
MIT_30C_10_500 = readtable('MIT 3D Print 30 C_BH_10.0A_500.csv');
MIT_30C_10_800 = readtable('MIT 3D Print 30 C_BH_10.0A_800.csv');
MIT_30C_10_1000 = readtable('MIT 3D Print 30 C_BH_10.0A_1000.csv');
MIT_30C_7_300 = readtable('MIT 3D Print 30 C_BH_7.0A_300.csv');
MIT_30C_8_300 = readtable('MIT 3D Print 30 C_BH_8.0A_300.csv');
MIT_30C_9_300 = readtable('MIT 3D Print 30 C_BH_9.0A_300.csv');
MIT_30C_12_300 = readtable('MIT 3D Print 30 C_BH_12.0A_300.csv');

Pack_MIT_30C_10_300 = Loop_Calc(MIT_30C_10_300);

% MnZn 30 C Open
MnZn_30C_Pow = readtable('MnZn_30 C.xlsx');
MnZn_30C_10_300 = readtable('MnZn 30 C_BH_10.0A_300.csv');
MnZn_30C_10_500 = readtable('MnZn 30 C_BH_10.0A_500.csv');
MnZn_30C_10_800 = readtable('MnZn 30 C_BH_10.0A_800.csv');
MnZn_30C_10_1000 = readtable('MnZn 30 C_BH_10.0A_1000.csv');
MnZn_30C_7_300 = readtable('MnZn 30 C_BH_7.0A_300.csv');
MnZn_30C_8_300 = readtable('MnZn 30 C_BH_8.0A_300.csv');
MnZn_30C_9_300 = readtable('MnZn 30 C_BH_9.0A_300.csv');
MnZn_30C_12_300 = readtable('MnZn 30 C_BH_12.0A_300.csv');

Pack_MnZn_30C_10_300 = Loop_Calc(MnZn_30C_10_300);

% PP 36.5 C Open
PP_36_5C_Pow = readtable('PP_36.5 C.xlsx');
PP_36_5C_10_300 = readtable('Protopasta 36.5 C_BH_10.0A_300.csv');
PP_36_5C_10_500 = readtable('Protopasta 36.5 C_BH_10.0A_500.csv');
PP_36_5C_10_800 = readtable('Protopasta 36.5 C_BH_10.0A_800.csv');
PP_36_5C_10_1000 = readtable('Protopasta 36.5 C_BH_10.0A_1000.csv');
PP_36_5C_7_300 = readtable('Protopasta 36.5 C_BH_7.0A_300.csv');
PP_36_5C_8_300 = readtable('Protopasta 36.5 C_BH_8.0A_300.csv');
PP_36_5C_9_300 = readtable('Protopasta 36.5 C_BH_9.0A_300.csv');
PP_36_5C_12_300 = readtable('Protopasta 36.5 C_BH_12.0A_300.csv');

Pack_PP_36_5C_10_300 = Loop_Calc(PP_36_5C_10_300);

% Moulded 36.5 C Open
Moulded_36_5C_Pow = readtable('Moulded_36.5 C.xlsx');
Moulded_36_5C_10_300 = readtable('Moulded 36.5 C_BH_10.0A_300.csv');
Moulded_36_5C_10_500 = readtable('Moulded 36.5 C_BH_10.0A_500.csv');
Moulded_36_5C_10_800 = readtable('Moulded 36.5 C_BH_10.0A_800.csv');
Moulded_36_5C_10_1000 = readtable('Moulded 36.5 C_BH_10.0A_1000.csv');
Moulded_36_5C_7_300 = readtable('Moulded 36.5 C_BH_7.0A_300.csv');
Moulded_36_5C_8_300 = readtable('Moulded 36.5 C_BH_8.0A_300.csv');
Moulded_36_5C_9_300 = readtable('Moulded 36.5 C_BH_9.0A_300.csv');
Moulded_36_5C_12_300 = readtable('Moulded 36.5 C_BH_12.0A_300.csv');

Pack_Moulded_36_5C_10_300 = Loop_Calc(Moulded_36_5C_10_300);

% MIT 36.5 C Open
MIT_36_5C_Pow = readtable('MIT_36.5 C.xlsx');
MIT_36_5C_10_300 = readtable('MIT 3D Print 36.5 C_BH_10.0A_300.csv');
MIT_36_5C_10_500 = readtable('MIT 3D Print 36.5 C_BH_10.0A_500.csv');
MIT_36_5C_10_800 = readtable('MIT 3D Print 36.5 C_BH_10.0A_800.csv');
MIT_36_5C_10_1000 = readtable('MIT 3D Print 36.5 C_BH_10.0A_1000.csv');
MIT_36_5C_7_300 = readtable('MIT 3D Print 36.5 C_BH_7.0A_300.csv');
MIT_36_5C_8_300 = readtable('MIT 3D Print 36.5 C_BH_8.0A_300.csv');
MIT_36_5C_9_300 = readtable('MIT 3D Print 36.5 C_BH_9.0A_300.csv');
MIT_36_5C_12_300 = readtable('MIT 3D Print 36.5 C_BH_12.0A_300.csv');

Pack_MIT_36_5C_10_300 = Loop_Calc(MIT_36_5C_10_300);

% MnZn 36.5 C Open
MnZn_36_5C_Pow = readtable('MnZn_36.5 C.xlsx');
MnZn_36_5C_10_300 = readtable('MnZn 36.5 C_BH_10.0A_300.csv');
MnZn_36_5C_10_500 = readtable('MnZn 36.5 C_BH_10.0A_500.csv');
MnZn_36_5C_10_800 = readtable('MnZn 36.5 C_BH_10.0A_800.csv');
MnZn_36_5C_10_1000 = readtable('MnZn 36.5 C_BH_10.0A_1000.csv');
MnZn_36_5C_7_300 = readtable('MnZn 36.5 C_BH_7.0A_300.csv');
MnZn_36_5C_8_300 = readtable('MnZn 36.5 C_BH_8.0A_300.csv');
MnZn_36_5C_9_300 = readtable('MnZn 36.5 C_BH_9.0A_300.csv');
MnZn_36_5C_12_300 = readtable('MnZn 36.5 C_BH_12.0A_300.csv');

Pack_MnZn_36_5C_10_300 = Loop_Calc(MnZn_36_5C_10_300);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% GRAPH SQUAD: SMOOTHING

figure;
plot(L10_Pow.I_RMS(1:10), L10_Pow.Voc_RMS(1:10), 'bo-', 'LineWidth', 2, 'DisplayName','Base Design');
hold on;
plot(Fillet_Pow.I_RMS(1:10), Fillet_Pow.Voc_RMS(1:10), 'ro-', 'LineWidth', 2, 'DisplayName','Filleted');
plot(Smooth_Pow.I_RMS(1:10), Smooth_Pow.Voc_RMS(1:10), 'ko-', 'LineWidth', 2, 'DisplayName','Smooth');
plot(Trapezoidal_Pow.I_RMS(1:10), Trapezoidal_Pow.Voc_RMS(1:10), 'go-', 'LineWidth', 2, 'DisplayName','Trapezoidal');
title('Smoothing Modifications OCV, 300 Hz');
xlabel('RMS Current (A)');
ylabel('Open-Circuit Voltage (V)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L10_Pow.I_RMS(11:20), L10_Pow.Voc_RMS(11:20), 'bo-', 'LineWidth', 2, 'DisplayName','Base Design');
hold on;
plot(Fillet_Pow.I_RMS(11:20), Fillet_Pow.Voc_RMS(11:20), 'ro-', 'LineWidth', 2, 'DisplayName','Filleted');
plot(Smooth_Pow.I_RMS(11:20), Smooth_Pow.Voc_RMS(11:20), 'ko-', 'LineWidth', 2, 'DisplayName','Smooth');
plot(Trapezoidal_Pow.I_RMS(11:20), Trapezoidal_Pow.Voc_RMS(11:20), 'go-', 'LineWidth', 2, 'DisplayName','Trapezoidal');
title('Smoothing Modifications OCV, 500 Hz');
xlabel('RMS Current (A)');
ylabel('Open-Circuit Voltage (V)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L10_Pow.I_RMS(21:30), L10_Pow.Voc_RMS(21:30), 'bo-', 'LineWidth', 2, 'DisplayName','Base Design');
hold on;
plot(Fillet_Pow.I_RMS(21:30), Fillet_Pow.Voc_RMS(21:30), 'ro-', 'LineWidth', 2, 'DisplayName','Filleted');
plot(Smooth_Pow.I_RMS(21:30), Smooth_Pow.Voc_RMS(21:30), 'ko-', 'LineWidth', 2, 'DisplayName','Smooth');
plot(Trapezoidal_Pow.I_RMS(21:30), Trapezoidal_Pow.Voc_RMS(21:30), 'go-', 'LineWidth', 2, 'DisplayName','Trapezoidal');
title('Smoothing Modifications OCV, 800 Hz');
xlabel('RMS Current (A)');
ylabel('Open-Circuit Voltage (V)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L10_Pow.I_RMS(31:40), L10_Pow.Voc_RMS(31:40), 'bo-', 'LineWidth', 2, 'DisplayName','Base Design');
hold on;
plot(Fillet_Pow.I_RMS(31:40), Fillet_Pow.Voc_RMS(31:40), 'ro-', 'LineWidth', 2, 'DisplayName','Filleted');
plot(Smooth_Pow.I_RMS(31:40), Smooth_Pow.Voc_RMS(31:40), 'ko-', 'LineWidth', 2, 'DisplayName','Smooth');
plot(Trapezoidal_Pow.I_RMS(31:40), Trapezoidal_Pow.Voc_RMS(31:40), 'go-', 'LineWidth', 2, 'DisplayName','Trapezoidal');
title('Smoothing Modifications OCV, 1000 Hz');
xlabel('RMS Current (A)');
ylabel('Open-Circuit Voltage (V)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L10_Pow.I_RMS(1:10), L10_Pow.Power_to_Mass(1:10), 'bo-', 'LineWidth', 2, 'DisplayName','Base Design');
hold on;
plot(Fillet_Pow.I_RMS(1:10), Fillet_Pow.Power_to_Mass(1:10), 'ro-', 'LineWidth', 2, 'DisplayName','Filleted');
plot(Smooth_Pow.I_RMS(1:10), Smooth_Pow.Power_to_Mass(1:10), 'ko-', 'LineWidth', 2, 'DisplayName','Smooth');
plot(Trapezoidal_Pow.I_RMS(1:10), Trapezoidal_Pow.Power_to_Mass(1:10), 'go-', 'LineWidth', 2, 'DisplayName','Trapezoidal');
title('Smoothing Modifications Power-Mass Ratio, 300 Hz');
xlabel('RMS Current (A)');
ylabel('Power-Mass Ratio (W/kg)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L10_Pow.I_RMS(11:20), L10_Pow.Power_to_Mass(11:20), 'bo-', 'LineWidth', 2, 'DisplayName','Base Design');
hold on;
plot(Fillet_Pow.I_RMS(11:20), Fillet_Pow.Power_to_Mass(11:20), 'ro-', 'LineWidth', 2, 'DisplayName','Filleted');
plot(Smooth_Pow.I_RMS(11:20), Smooth_Pow.Power_to_Mass(11:20), 'ko-', 'LineWidth', 2, 'DisplayName','Smooth');
plot(Trapezoidal_Pow.I_RMS(11:20), Trapezoidal_Pow.Power_to_Mass(11:20), 'go-', 'LineWidth', 2, 'DisplayName','Trapezoidal');
title('Smoothing Modifications Power-Mass Ratio, 500 Hz');
xlabel('RMS Current (A)');
ylabel('Power-Mass Ratio (W/kg)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L10_Pow.I_RMS(21:30), L10_Pow.Power_to_Mass(21:30), 'bo-', 'LineWidth', 2, 'DisplayName','Base Design');
hold on;
plot(Fillet_Pow.I_RMS(21:30), Fillet_Pow.Power_to_Mass(21:30), 'ro-', 'LineWidth', 2, 'DisplayName','Filleted');
plot(Smooth_Pow.I_RMS(21:30), Smooth_Pow.Power_to_Mass(21:30), 'ko-', 'LineWidth', 2, 'DisplayName','Smooth');
plot(Trapezoidal_Pow.I_RMS(21:30), Trapezoidal_Pow.Power_to_Mass(21:30), 'go-', 'LineWidth', 2, 'DisplayName','Trapezoidal');
title('Smoothing Modifications Power-Mass Ratio, 800 Hz');
xlabel('RMS Current (A)');
ylabel('Power-Mass Ratio (W/kg)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L10_Pow.I_RMS(31:40), L10_Pow.Power_to_Mass(31:40), 'bo-', 'LineWidth', 2, 'DisplayName','Base Design');
hold on;
plot(Fillet_Pow.I_RMS(31:40), Fillet_Pow.Power_to_Mass(31:40), 'ro-', 'LineWidth', 2, 'DisplayName','Filleted');
plot(Smooth_Pow.I_RMS(31:40), Smooth_Pow.Power_to_Mass(31:40), 'ko-', 'LineWidth', 2, 'DisplayName','Smooth');
plot(Trapezoidal_Pow.I_RMS(31:40), Trapezoidal_Pow.Power_to_Mass(31:40), 'go-', 'LineWidth', 2, 'DisplayName','Trapezoidal');
title('Smoothing Modifications Power-Mass Ratio, 1000 Hz');
xlabel('RMS Current (A)');
ylabel('Power-Mass Ratio (W/kg)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L10_10_300.H_Loop, L10_10_300.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','Base Design');
hold on;
plot(Fillet_10_300.H_Loop, Fillet_10_300.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','Filleted');
plot(Smooth_10_300.H_Loop, Smooth_10_300.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','Smooth');
plot(Trapezoidal_10_300.H_Loop, Trapezoidal_10_300.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','Trapezoidal');
title('Smoothing Modifications B-H Loops 10A, 300 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L10_10_500.H_Loop, L10_10_500.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','Base Design');
hold on;
plot(Fillet_10_500.H_Loop, Fillet_10_500.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','Filleted');
plot(Smooth_10_500.H_Loop, Smooth_10_500.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','Smooth');
plot(Trapezoidal_10_500.H_Loop, Trapezoidal_10_500.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','Trapezoidal');
title('Smoothing Modifications B-H Loops 10A, 500 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L10_10_800.H_Loop, L10_10_800.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','Base Design');
hold on;
plot(Fillet_10_800.H_Loop, Fillet_10_800.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','Filleted');
plot(Smooth_10_800.H_Loop, Smooth_10_800.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','Smooth');
plot(Trapezoidal_10_800.H_Loop, Trapezoidal_10_800.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','Trapezoidal');
title('Smoothing Modifications B-H Loops 10A, 800 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L10_10_1000.H_Loop, L10_10_1000.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','Base Design');
hold on;
plot(Fillet_10_1000.H_Loop, Fillet_10_1000.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','Filleted');
plot(Smooth_10_1000.H_Loop, Smooth_10_1000.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','Smooth');
plot(Trapezoidal_10_1000.H_Loop, Trapezoidal_10_1000.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','Trapezoidal');
title('Smoothing Modifications B-H Loops 10A, 1000 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L10_7_300.H_Loop, L10_7_300.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','7A');
hold on;
plot(L10_8_300.H_Loop, L10_8_300.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','8A');
plot(L10_9_300.H_Loop, L10_9_300.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','9A');
plot(L10_10_300.H_Loop, L10_10_300.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','10A');
plot(L10_12_300.H_Loop, L10_12_300.B_Loop, 'c-', 'LineWidth', 2, 'DisplayName','12A');
title('Base Design B-H Loops at 300 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(Fillet_7_300.H_Loop, Fillet_7_300.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','7A');
hold on;
plot(Fillet_8_300.H_Loop, Fillet_8_300.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','8A');
plot(Fillet_9_300.H_Loop, Fillet_9_300.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','9A');
plot(Fillet_10_300.H_Loop, Fillet_10_300.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','10A');
plot(Fillet_12_300.H_Loop, Fillet_12_300.B_Loop, 'c-', 'LineWidth', 2, 'DisplayName','12A');
title('Filleted Design B-H Loops at 300 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(Trapezoidal_7_300.H_Loop, Trapezoidal_7_300.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','7A');
hold on;
plot(Trapezoidal_8_300.H_Loop, Trapezoidal_8_300.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','8A');
plot(Trapezoidal_9_300.H_Loop, Trapezoidal_9_300.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','9A');
plot(Trapezoidal_10_300.H_Loop, Trapezoidal_10_300.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','10A');
plot(Trapezoidal_12_300.H_Loop, Trapezoidal_12_300.B_Loop, 'c-', 'LineWidth', 2, 'DisplayName','12A');
title('Trapezoidal Design B-H Loops at 300 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(Smooth_7_300.H_Loop, Smooth_7_300.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','7A');
hold on;
plot(Smooth_8_300.H_Loop, Smooth_8_300.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','8A');
plot(Smooth_9_300.H_Loop, Smooth_9_300.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','9A');
plot(Smooth_10_300.H_Loop, Smooth_10_300.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','10A');
plot(Smooth_12_300.H_Loop, Smooth_12_300.B_Loop, 'c-', 'LineWidth', 2, 'DisplayName','12A');
title('Smooth Design B-H Loops at 300 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% GRAPH SQUAD: WIDTH

figure;
plot(W2_5_Pow.I_RMS(1:10), W2_5_Pow.Voc_RMS(1:10), 'bo-', 'LineWidth', 2, 'DisplayName','Width: 2.5 mm');
hold on;
plot(W5_Pow.I_RMS(1:10), W5_Pow.Voc_RMS(1:10), 'ro-', 'LineWidth', 2, 'DisplayName','Width: 5 mm');
plot(W7_5_Pow.I_RMS(1:10), W7_5_Pow.Voc_RMS(1:10), 'ko-', 'LineWidth', 2, 'DisplayName','Width: 7.5 mm');
plot(W10_Pow.I_RMS(1:10), W10_Pow.Voc_RMS(1:10), 'go-', 'LineWidth', 2, 'DisplayName','Width: 10 mm');
plot(W12_5_Pow.I_RMS(1:10), W12_5_Pow.Voc_RMS(1:10), 'co-', 'LineWidth', 2, 'DisplayName','Width: 12.5 mm');
title('Width Modifications OCV, 300 Hz');
xlabel('RMS Current (A)');
ylabel('Open-Circuit Voltage (V)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(W2_5_Pow.I_RMS(11:20), W2_5_Pow.Voc_RMS(11:20), 'bo-', 'LineWidth', 2, 'DisplayName','Width: 2.5 mm');
hold on;
plot(W5_Pow.I_RMS(11:20), W5_Pow.Voc_RMS(11:20), 'ro-', 'LineWidth', 2, 'DisplayName','Width: 5 mm');
plot(W7_5_Pow.I_RMS(11:20), W7_5_Pow.Voc_RMS(11:20), 'ko-', 'LineWidth', 2, 'DisplayName','Width: 7.5 mm');
plot(W10_Pow.I_RMS(11:20), W10_Pow.Voc_RMS(11:20), 'go-', 'LineWidth', 2, 'DisplayName','Width: 10 mm');
plot(W12_5_Pow.I_RMS(11:20), W12_5_Pow.Voc_RMS(11:20), 'co-', 'LineWidth', 2, 'DisplayName','Width: 12.5 mm');
title('Width Modifications OCV, 500 Hz');
xlabel('RMS Current (A)');
ylabel('Open-Circuit Voltage (V)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(W2_5_Pow.I_RMS(21:30), W2_5_Pow.Voc_RMS(21:30), 'bo-', 'LineWidth', 2, 'DisplayName','Width: 2.5 mm');
hold on;
plot(W5_Pow.I_RMS(21:30), W5_Pow.Voc_RMS(21:30), 'ro-', 'LineWidth', 2, 'DisplayName','Width: 5 mm');
plot(W7_5_Pow.I_RMS(21:30), W7_5_Pow.Voc_RMS(21:30), 'ko-', 'LineWidth', 2, 'DisplayName','Width: 7.5 mm');
plot(W10_Pow.I_RMS(21:30), W10_Pow.Voc_RMS(21:30), 'go-', 'LineWidth', 2, 'DisplayName','Width: 10 mm');
plot(W12_5_Pow.I_RMS(21:30), W12_5_Pow.Voc_RMS(21:30), 'co-', 'LineWidth', 2, 'DisplayName','Width: 12.5 mm');
title('Width Modifications OCV, 800 Hz');
xlabel('RMS Current (A)');
ylabel('Open-Circuit Voltage (V)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(W2_5_Pow.I_RMS(31:40), W2_5_Pow.Voc_RMS(31:40), 'bo-', 'LineWidth', 2, 'DisplayName','Width: 2.5 mm');
hold on;
plot(W5_Pow.I_RMS(31:40), W5_Pow.Voc_RMS(31:40), 'ro-', 'LineWidth', 2, 'DisplayName','Width: 5 mm');
plot(W7_5_Pow.I_RMS(31:40), W7_5_Pow.Voc_RMS(31:40), 'ko-', 'LineWidth', 2, 'DisplayName','Width: 7.5 mm');
plot(W10_Pow.I_RMS(31:40), W10_Pow.Voc_RMS(31:40), 'go-', 'LineWidth', 2, 'DisplayName','Width: 10 mm');
plot(W12_5_Pow.I_RMS(31:40), W12_5_Pow.Voc_RMS(31:40), 'co-', 'LineWidth', 2, 'DisplayName','Width: 12.5 mm');
title('Width Modifications OCV, 1000 Hz');
xlabel('RMS Current (A)');
ylabel('Open-Circuit Voltage (V)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(W2_5_Pow.I_RMS(1:10), W2_5_Pow.Power_to_Mass(1:10), 'bo-', 'LineWidth', 2, 'DisplayName','Width: 2.5 mm');
hold on;
plot(W5_Pow.I_RMS(1:10), W5_Pow.Power_to_Mass(1:10), 'ro-', 'LineWidth', 2, 'DisplayName','Width: 5 mm');
plot(W7_5_Pow.I_RMS(1:10), W7_5_Pow.Power_to_Mass(1:10), 'ko-', 'LineWidth', 2, 'DisplayName','Width: 7.5 mm');
plot(W10_Pow.I_RMS(1:10), W10_Pow.Power_to_Mass(1:10), 'go-', 'LineWidth', 2, 'DisplayName','Width: 10 mm');
plot(W12_5_Pow.I_RMS(1:10), W12_5_Pow.Power_to_Mass(1:10), 'co-', 'LineWidth', 2, 'DisplayName','Width: 12.5 mm');
title('Width Modifications Power-Mass Ratio, 300 Hz');
xlabel('RMS Current (A)');
ylabel('Power-Mass Ratio (W/kg)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(W2_5_Pow.I_RMS(11:20), W2_5_Pow.Power_to_Mass(11:20), 'bo-', 'LineWidth', 2, 'DisplayName','Width: 2.5 mm');
hold on;
plot(W5_Pow.I_RMS(11:20), W5_Pow.Power_to_Mass(11:20), 'ro-', 'LineWidth', 2, 'DisplayName','Width: 5 mm');
plot(W7_5_Pow.I_RMS(11:20), W7_5_Pow.Power_to_Mass(11:20), 'ko-', 'LineWidth', 2, 'DisplayName','Width: 7.5 mm');
plot(W10_Pow.I_RMS(11:20), W10_Pow.Power_to_Mass(11:20), 'go-', 'LineWidth', 2, 'DisplayName','Width: 10 mm');
plot(W12_5_Pow.I_RMS(11:20), W12_5_Pow.Power_to_Mass(11:20), 'co-', 'LineWidth', 2, 'DisplayName','Width: 12.5 mm');
title('Width Modifications Power-Mass Ratio, 500 Hz');
xlabel('RMS Current (A)');
ylabel('Power-Mass Ratio (W/kg)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(W2_5_Pow.I_RMS(21:30), W2_5_Pow.Power_to_Mass(21:30), 'bo-', 'LineWidth', 2, 'DisplayName','Width: 2.5 mm');
hold on;
plot(W5_Pow.I_RMS(21:30), W5_Pow.Power_to_Mass(21:30), 'ro-', 'LineWidth', 2, 'DisplayName','Width: 5 mm');
plot(W7_5_Pow.I_RMS(21:30), W7_5_Pow.Power_to_Mass(21:30), 'ko-', 'LineWidth', 2, 'DisplayName','Width: 7.5 mm');
plot(W10_Pow.I_RMS(21:30), W10_Pow.Power_to_Mass(21:30), 'go-', 'LineWidth', 2, 'DisplayName','Width: 10 mm');
plot(W12_5_Pow.I_RMS(21:30), W12_5_Pow.Power_to_Mass(21:30), 'co-', 'LineWidth', 2, 'DisplayName','Width: 12.5 mm');
title('Width Modifications Power-Mass Ratio, 800 Hz');
xlabel('RMS Current (A)');
ylabel('Power-Mass Ratio (W/kg)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(W2_5_Pow.I_RMS(31:40), W2_5_Pow.Power_to_Mass(31:40), 'bo-', 'LineWidth', 2, 'DisplayName','Width: 2.5 mm');
hold on;
plot(W5_Pow.I_RMS(31:40), W5_Pow.Power_to_Mass(31:40), 'ro-', 'LineWidth', 2, 'DisplayName','Width: 5 mm');
plot(W7_5_Pow.I_RMS(31:40), W7_5_Pow.Power_to_Mass(31:40), 'ko-', 'LineWidth', 2, 'DisplayName','Width: 7.5 mm');
plot(W10_Pow.I_RMS(31:40), W10_Pow.Power_to_Mass(31:40), 'go-', 'LineWidth', 2, 'DisplayName','Width: 10 mm');
plot(W12_5_Pow.I_RMS(31:40), W12_5_Pow.Power_to_Mass(31:40), 'co-', 'LineWidth', 2, 'DisplayName','Width: 12.5 mm');
title('Width Modifications Power-Mass Ratio, 1000 Hz');
xlabel('RMS Current (A)');
ylabel('Power-Mass Ratio (W/kg)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(W2_5_10_300.H_Loop, W2_5_10_300.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','Width: 2.5 mm');
hold on;
plot(W5_10_300.H_Loop, W5_10_300.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','Width: 5 mm');
plot(W7_5_10_300.H_Loop, W7_5_10_300.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','Width: 7.5 mm');
plot(W10_10_300.H_Loop, W10_10_300.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','Width: 10 mm');
plot(W12_5_10_300.H_Loop, W12_5_10_300.B_Loop, 'c-', 'LineWidth', 2, 'DisplayName','Width: 12.5 mm');
title('Width Modifications B-H Loops 10A, 300 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(W2_5_10_500.H_Loop, W2_5_10_500.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','Width: 2.5 mm');
hold on;
plot(W5_10_500.H_Loop, W5_10_500.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','Width: 5 mm');
plot(W7_5_10_500.H_Loop, W7_5_10_500.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','Width: 7.5 mm');
plot(W10_10_500.H_Loop, W10_10_500.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','Width: 10 mm');
plot(W12_5_10_500.H_Loop, W12_5_10_500.B_Loop, 'c-', 'LineWidth', 2, 'DisplayName','Width: 12.5 mm');
title('Width Modifications B-H Loops 10A, 500 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(W2_5_10_800.H_Loop, W2_5_10_800.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','Width: 2.5 mm');
hold on;
plot(W5_10_800.H_Loop, W5_10_800.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','Width: 5 mm');
plot(W7_5_10_800.H_Loop, W7_5_10_800.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','Width: 7.5 mm');
plot(W10_10_800.H_Loop, W10_10_800.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','Width: 10 mm');
plot(W12_5_10_800.H_Loop, W12_5_10_800.B_Loop, 'c-', 'LineWidth', 2, 'DisplayName','Width: 12.5 mm');
title('Width Modifications B-H Loops 10A, 800 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(W2_5_10_1000.H_Loop, W2_5_10_1000.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','Width: 2.5 mm');
hold on;
plot(W5_10_1000.H_Loop, W5_10_1000.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','Width: 5 mm');
plot(W7_5_10_1000.H_Loop, W7_5_10_1000.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','Width: 7.5 mm');
plot(W10_10_1000.H_Loop, W10_10_1000.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','Width: 10 mm');
plot(W12_5_10_1000.H_Loop, W12_5_10_1000.B_Loop, 'c-', 'LineWidth', 2, 'DisplayName','Width: 12.5 mm');
title('Width Modifications B-H Loops 10A, 1000 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(W2_5_7_300.H_Loop, W2_5_7_300.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','7A');
hold on;
plot(W2_5_8_300.H_Loop, W2_5_8_300.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','8A');
plot(W2_5_9_300.H_Loop, W2_5_9_300.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','9A');
plot(W2_5_10_300.H_Loop, W2_5_10_300.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','10A');
plot(W2_5_12_300.H_Loop, W2_5_12_300.B_Loop, 'c-', 'LineWidth', 2, 'DisplayName','12A');
title('Width: 2.5 mm Design B-H Loops at 300 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(W5_7_300.H_Loop, W5_7_300.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','7A');
hold on;
plot(W5_8_300.H_Loop, W5_8_300.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','8A');
plot(W5_9_300.H_Loop, W5_9_300.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','9A');
plot(W5_10_300.H_Loop, W5_10_300.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','10A');
plot(W5_12_300.H_Loop, W5_12_300.B_Loop, 'c-', 'LineWidth', 2, 'DisplayName','12A');
title('Width: 5 mm Design B-H Loops at 300 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(W7_5_7_300.H_Loop, W7_5_7_300.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','7A');
hold on;
plot(W7_5_8_300.H_Loop, W7_5_8_300.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','8A');
plot(W7_5_9_300.H_Loop, W7_5_9_300.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','9A');
plot(W7_5_10_300.H_Loop, W7_5_10_300.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','10A');
plot(W7_5_12_300.H_Loop, W7_5_12_300.B_Loop, 'c-', 'LineWidth', 2, 'DisplayName','12A');
title('Width: 7.5 mm Design B-H Loops at 300 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(W10_7_300.H_Loop, W10_7_300.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','7A');
hold on;
plot(W10_8_300.H_Loop, W10_8_300.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','8A');
plot(W10_9_300.H_Loop, W10_9_300.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','9A');
plot(W10_10_300.H_Loop, W10_10_300.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','10A');
plot(W10_12_300.H_Loop, W10_12_300.B_Loop, 'c-', 'LineWidth', 2, 'DisplayName','12A');
title('Width: 10 mm Design B-H Loops at 300 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(W12_5_7_300.H_Loop, W12_5_7_300.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','7A');
hold on;
plot(W12_5_8_300.H_Loop, W12_5_8_300.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','8A');
plot(W12_5_9_300.H_Loop, W12_5_9_300.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','9A');
plot(W12_5_10_300.H_Loop, W12_5_10_300.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','10A');
plot(W12_5_12_300.H_Loop, W12_5_12_300.B_Loop, 'c-', 'LineWidth', 2, 'DisplayName','12A');
title('Width: 12.5 mm Design B-H Loops at 300 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% GRAPH SQUAD: FLANGE LENGTH

figure;
plot(FL10_Pow.I_RMS(1:10), FL10_Pow.Voc_RMS(1:10), 'bo-', 'LineWidth', 2, 'DisplayName','Flange Length: 10 mm');
hold on;
plot(FL20_Pow.I_RMS(1:10), FL20_Pow.Voc_RMS(1:10), 'ro-', 'LineWidth', 2, 'DisplayName','Flange Length: 20 mm');
plot(FL30_Pow.I_RMS(1:10), FL30_Pow.Voc_RMS(1:10), 'ko-', 'LineWidth', 2, 'DisplayName','Flange Length: 30 mm');
plot(FL40_Pow.I_RMS(1:10), FL40_Pow.Voc_RMS(1:10), 'go-', 'LineWidth', 2, 'DisplayName','Flange Length: 40 mm');
plot(FL50_Pow.I_RMS(1:10), FL50_Pow.Voc_RMS(1:10), 'co-', 'LineWidth', 2, 'DisplayName','Flange Length: 50 mm');
title('Flange Length Modifications OCV, 300 Hz');
xlabel('RMS Current (A)');
ylabel('Open-Circuit Voltage (V)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(FL10_Pow.I_RMS(11:20), FL10_Pow.Voc_RMS(11:20), 'bo-', 'LineWidth', 2, 'DisplayName','Flange Length: 10 mm');
hold on;
plot(FL20_Pow.I_RMS(11:20), FL20_Pow.Voc_RMS(11:20), 'ro-', 'LineWidth', 2, 'DisplayName','Flange Length: 20 mm');
plot(FL30_Pow.I_RMS(11:20), FL30_Pow.Voc_RMS(11:20), 'ko-', 'LineWidth', 2, 'DisplayName','Flange Length: 30 mm');
plot(FL40_Pow.I_RMS(11:20), FL40_Pow.Voc_RMS(11:20), 'go-', 'LineWidth', 2, 'DisplayName','Flange Length: 40 mm');
plot(FL50_Pow.I_RMS(11:20), FL50_Pow.Voc_RMS(11:20), 'co-', 'LineWidth', 2, 'DisplayName','Flange Length: 50 mm');
title('Flange Length Modifications OCV, 500 Hz');
xlabel('RMS Current (A)');
ylabel('Open-Circuit Voltage (V)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(FL10_Pow.I_RMS(21:30), FL10_Pow.Voc_RMS(21:30), 'bo-', 'LineWidth', 2, 'DisplayName','Flange Length: 10 mm');
hold on;
plot(FL20_Pow.I_RMS(21:30), FL20_Pow.Voc_RMS(21:30), 'ro-', 'LineWidth', 2, 'DisplayName','Flange Length: 20 mm');
plot(FL30_Pow.I_RMS(21:30), FL30_Pow.Voc_RMS(21:30), 'ko-', 'LineWidth', 2, 'DisplayName','Flange Length: 30 mm');
plot(FL40_Pow.I_RMS(21:30), FL40_Pow.Voc_RMS(21:30), 'go-', 'LineWidth', 2, 'DisplayName','Flange Length: 40 mm');
plot(FL50_Pow.I_RMS(21:30), FL50_Pow.Voc_RMS(21:30), 'co-', 'LineWidth', 2, 'DisplayName','Flange Length: 50 mm');
title('Flange Length Modifications OCV, 800 Hz');
xlabel('RMS Current (A)');
ylabel('Open-Circuit Voltage (V)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(FL10_Pow.I_RMS(31:40), FL10_Pow.Voc_RMS(31:40), 'bo-', 'LineWidth', 2, 'DisplayName','Flange Length: 10 mm');
hold on;
plot(FL20_Pow.I_RMS(31:40), FL20_Pow.Voc_RMS(31:40), 'ro-', 'LineWidth', 2, 'DisplayName','Flange Length: 20 mm');
plot(FL30_Pow.I_RMS(31:40), FL30_Pow.Voc_RMS(31:40), 'ko-', 'LineWidth', 2, 'DisplayName','Flange Length: 30 mm');
plot(FL40_Pow.I_RMS(31:40), FL40_Pow.Voc_RMS(31:40), 'go-', 'LineWidth', 2, 'DisplayName','Flange Length: 40 mm');
plot(FL50_Pow.I_RMS(31:40), FL50_Pow.Voc_RMS(31:40), 'co-', 'LineWidth', 2, 'DisplayName','Flange Length: 50 mm');
title('Flange Length Modifications OCV, 1000 Hz');
xlabel('RMS Current (A)');
ylabel('Open-Circuit Voltage (V)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(FL10_Pow.I_RMS(1:10), FL10_Pow.Power_to_Mass(1:10), 'bo-', 'LineWidth', 2, 'DisplayName','Flange Length: 10 mm');
hold on;
plot(FL20_Pow.I_RMS(1:10), FL20_Pow.Power_to_Mass(1:10), 'ro-', 'LineWidth', 2, 'DisplayName','Flange Length: 20 mm');
plot(FL30_Pow.I_RMS(1:10), FL30_Pow.Power_to_Mass(1:10), 'ko-', 'LineWidth', 2, 'DisplayName','Flange Length: 30 mm');
plot(FL40_Pow.I_RMS(1:10), FL40_Pow.Power_to_Mass(1:10), 'go-', 'LineWidth', 2, 'DisplayName','Flange Length: 40 mm');
plot(FL50_Pow.I_RMS(1:10), FL50_Pow.Power_to_Mass(1:10), 'co-', 'LineWidth', 2, 'DisplayName','Flange Length: 50 mm');
title('Flange Length Modifications Power-Mass Ratio, 300 Hz');
xlabel('RMS Current (A)');
ylabel('Power-Mass Ratio (W/kg)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(FL10_Pow.I_RMS(11:20), FL10_Pow.Power_to_Mass(11:20), 'bo-', 'LineWidth', 2, 'DisplayName','Flange Length: 10 mm');
hold on;
plot(FL20_Pow.I_RMS(11:20), FL20_Pow.Power_to_Mass(11:20), 'ro-', 'LineWidth', 2, 'DisplayName','Flange Length: 20 mm');
plot(FL30_Pow.I_RMS(11:20), FL30_Pow.Power_to_Mass(11:20), 'ko-', 'LineWidth', 2, 'DisplayName','Flange Length: 30 mm');
plot(FL40_Pow.I_RMS(11:20), FL40_Pow.Power_to_Mass(11:20), 'go-', 'LineWidth', 2, 'DisplayName','Flange Length: 40 mm');
plot(FL50_Pow.I_RMS(11:20), FL50_Pow.Power_to_Mass(11:20), 'co-', 'LineWidth', 2, 'DisplayName','Flange Length: 50 mm');
title('Flange Length Modifications Power-Mass Ratio, 500 Hz');
xlabel('RMS Current (A)');
ylabel('Power-Mass Ratio (W/kg)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(FL10_Pow.I_RMS(21:30), FL10_Pow.Power_to_Mass(21:30), 'bo-', 'LineWidth', 2, 'DisplayName','Flange Length: 10 mm');
hold on;
plot(FL20_Pow.I_RMS(21:30), FL20_Pow.Power_to_Mass(21:30), 'ro-', 'LineWidth', 2, 'DisplayName','Flange Length: 20 mm');
plot(FL30_Pow.I_RMS(21:30), FL30_Pow.Power_to_Mass(21:30), 'ko-', 'LineWidth', 2, 'DisplayName','Flange Length: 30 mm');
plot(FL40_Pow.I_RMS(21:30), FL40_Pow.Power_to_Mass(21:30), 'go-', 'LineWidth', 2, 'DisplayName','Flange Length: 40 mm');
plot(FL50_Pow.I_RMS(21:30), FL50_Pow.Power_to_Mass(21:30), 'co-', 'LineWidth', 2, 'DisplayName','Flange Length: 50 mm');
title('Flange Length Modifications Power-Mass Ratio, 800 Hz');
xlabel('RMS Current (A)');
ylabel('Power-Mass Ratio (W/kg)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(FL10_Pow.I_RMS(31:40), FL10_Pow.Power_to_Mass(31:40), 'bo-', 'LineWidth', 2, 'DisplayName','Flange Length: 10 mm');
hold on;
plot(FL20_Pow.I_RMS(31:40), FL20_Pow.Power_to_Mass(31:40), 'ro-', 'LineWidth', 2, 'DisplayName','Flange Length: 20 mm');
plot(FL30_Pow.I_RMS(31:40), FL30_Pow.Power_to_Mass(31:40), 'ko-', 'LineWidth', 2, 'DisplayName','Flange Length: 30 mm');
plot(FL40_Pow.I_RMS(31:40), FL40_Pow.Power_to_Mass(31:40), 'go-', 'LineWidth', 2, 'DisplayName','Flange Length: 40 mm');
plot(FL50_Pow.I_RMS(31:40), FL50_Pow.Power_to_Mass(31:40), 'co-', 'LineWidth', 2, 'DisplayName','Flange Length: 50 mm');
title('Flange Length Modifications Power-Mass Ratio, 1000 Hz');
xlabel('RMS Current (A)');
ylabel('Power-Mass Ratio (W/kg)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(FL10_10_300.H_Loop, FL10_10_300.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','Flange Length: 10 mm');
hold on;
plot(FL20_10_300.H_Loop, FL20_10_300.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','Flange Length: 20 mm');
plot(FL30_10_300.H_Loop, FL30_10_300.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','Flange Length: 30 mm');
plot(FL40_10_300.H_Loop, FL40_10_300.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','Flange Length: 40 mm');
plot(FL50_10_300.H_Loop, FL50_10_300.B_Loop, 'c-', 'LineWidth', 2, 'DisplayName','Flange Length: 50 mm');
title('Flange Length Modifications B-H Loops 10A, 300 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(FL10_10_500.H_Loop, FL10_10_500.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','Flange Length: 10 mm');
hold on;
plot(FL20_10_500.H_Loop, FL20_10_500.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','Flange Length: 20 mm');
plot(FL30_10_500.H_Loop, FL30_10_500.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','Flange Length: 30 mm');
plot(FL40_10_500.H_Loop, FL40_10_500.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','Flange Length: 40 mm');
plot(FL50_10_500.H_Loop, FL50_10_500.B_Loop, 'c-', 'LineWidth', 2, 'DisplayName','Flange Length: 50 mm');
title('Flange Length Modifications B-H Loops 10A, 500 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(FL10_10_800.H_Loop, FL10_10_800.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','Flange Length: 10 mm');
hold on;
plot(FL20_10_800.H_Loop, FL20_10_800.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','Flange Length: 20 mm');
plot(FL30_10_800.H_Loop, FL30_10_800.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','Flange Length: 30 mm');
plot(FL40_10_800.H_Loop, FL40_10_800.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','Flange Length: 40 mm');
plot(FL50_10_800.H_Loop, FL50_10_800.B_Loop, 'c-', 'LineWidth', 2, 'DisplayName','Flange Length: 50 mm');
title('Flange Length Modifications B-H Loops 10A, 800 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(FL10_10_1000.H_Loop, FL10_10_1000.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','Flange Length: 10 mm');
hold on;
plot(FL20_10_1000.H_Loop, FL20_10_1000.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','Flange Length: 20 mm');
plot(FL30_10_1000.H_Loop, FL30_10_1000.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','Flange Length: 30 mm');
plot(FL40_10_1000.H_Loop, FL40_10_1000.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','Flange Length: 40 mm');
plot(FL50_10_1000.H_Loop, FL50_10_1000.B_Loop, 'c-', 'LineWidth', 2, 'DisplayName','Flange Length: 50 mm');
title('Flange Length Modifications B-H Loops 10A, 1000 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(FL10_7_300.H_Loop, FL10_7_300.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','7A');
hold on;
plot(FL10_8_300.H_Loop, FL10_8_300.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','8A');
plot(FL10_9_300.H_Loop, FL10_9_300.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','9A');
plot(FL10_10_300.H_Loop, FL10_10_300.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','10A');
plot(FL10_12_300.H_Loop, FL10_12_300.B_Loop, 'c-', 'LineWidth', 2, 'DisplayName','12A');
title('Flange Length: 10 mm Design B-H Loops at 300 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(FL20_7_300.H_Loop, FL20_7_300.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','7A');
hold on;
plot(FL20_8_300.H_Loop, FL20_8_300.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','8A');
plot(FL20_9_300.H_Loop, FL20_9_300.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','9A');
plot(FL20_10_300.H_Loop, FL20_10_300.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','10A');
plot(FL20_12_300.H_Loop, FL20_12_300.B_Loop, 'c-', 'LineWidth', 2, 'DisplayName','12A');
title('Flange Length: 20 mm Design B-H Loops at 300 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(FL30_7_300.H_Loop, FL30_7_300.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','7A');
hold on;
plot(FL30_8_300.H_Loop, FL30_8_300.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','8A');
plot(FL30_9_300.H_Loop, FL30_9_300.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','9A');
plot(FL30_10_300.H_Loop, FL30_10_300.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','10A');
plot(FL30_12_300.H_Loop, FL30_12_300.B_Loop, 'c-', 'LineWidth', 2, 'DisplayName','12A');
title('Flange Length: 30 mm Design B-H Loops at 300 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(FL40_7_300.H_Loop, FL40_7_300.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','7A');
hold on;
plot(FL40_8_300.H_Loop, FL40_8_300.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','8A');
plot(FL40_9_300.H_Loop, FL40_9_300.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','9A');
plot(FL40_10_300.H_Loop, FL40_10_300.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','10A');
plot(FL40_12_300.H_Loop, FL40_12_300.B_Loop, 'c-', 'LineWidth', 2, 'DisplayName','12A');
title('Flange Length: 40 mm Design B-H Loops at 300 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(FL50_7_300.H_Loop, FL50_7_300.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','7A');
hold on;
plot(FL50_8_300.H_Loop, FL50_8_300.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','8A');
plot(FL50_9_300.H_Loop, FL50_9_300.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','9A');
plot(FL50_10_300.H_Loop, FL50_10_300.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','10A');
plot(FL50_12_300.H_Loop, FL50_12_300.B_Loop, 'c-', 'LineWidth', 2, 'DisplayName','12A');
title('Flange Length: 50 mm Design B-H Loops at 300 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% GRAPH SQUAD: LENGTH

figure;
plot(L5_Pow.I_RMS(1:10), L5_Pow.Voc_RMS(1:10), 'bo-', 'LineWidth', 2, 'DisplayName','Length: 5 mm');
hold on;
plot(L10_Pow.I_RMS(1:10), L10_Pow.Voc_RMS(1:10), 'ro-', 'LineWidth', 2, 'DisplayName','Length: 10 mm');
plot(L15_Pow.I_RMS(1:10), L15_Pow.Voc_RMS(1:10), 'ko-', 'LineWidth', 2, 'DisplayName','Length: 15 mm');
plot(L20_Pow.I_RMS(1:10), L20_Pow.Voc_RMS(1:10), 'go-', 'LineWidth', 2, 'DisplayName','Length: 20 mm');
plot(L25_Pow.I_RMS(1:10), L25_Pow.Voc_RMS(1:10), 'co-', 'LineWidth', 2, 'DisplayName','Length: 25 mm');
title('Length Modifications OCV, 300 Hz');
xlabel('RMS Current (A)');
ylabel('Open-Circuit Voltage (V)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L5_Pow.I_RMS(11:20), L5_Pow.Voc_RMS(11:20), 'bo-', 'LineWidth', 2, 'DisplayName','Length: 5 mm');
hold on;
plot(L10_Pow.I_RMS(11:20), L10_Pow.Voc_RMS(11:20), 'ro-', 'LineWidth', 2, 'DisplayName','Length: 10 mm');
plot(L15_Pow.I_RMS(11:20), L15_Pow.Voc_RMS(11:20), 'ko-', 'LineWidth', 2, 'DisplayName','Length: 15 mm');
plot(L20_Pow.I_RMS(11:20), L20_Pow.Voc_RMS(11:20), 'go-', 'LineWidth', 2, 'DisplayName','Length: 20 mm');
plot(L25_Pow.I_RMS(11:20), L25_Pow.Voc_RMS(11:20), 'co-', 'LineWidth', 2, 'DisplayName','Length: 25 mm');
title('Length Modifications OCV, 500 Hz');
xlabel('RMS Current (A)');
ylabel('Open-Circuit Voltage (V)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L5_Pow.I_RMS(21:30), L5_Pow.Voc_RMS(21:30), 'bo-', 'LineWidth', 2, 'DisplayName','Length: 5 mm');
hold on;
plot(L10_Pow.I_RMS(21:30), L10_Pow.Voc_RMS(21:30), 'ro-', 'LineWidth', 2, 'DisplayName','Length: 10 mm');
plot(L15_Pow.I_RMS(21:30), L15_Pow.Voc_RMS(21:30), 'ko-', 'LineWidth', 2, 'DisplayName','Length: 15 mm');
plot(L20_Pow.I_RMS(21:30), L20_Pow.Voc_RMS(21:30), 'go-', 'LineWidth', 2, 'DisplayName','Length: 20 mm');
plot(L25_Pow.I_RMS(21:30), L25_Pow.Voc_RMS(21:30), 'co-', 'LineWidth', 2, 'DisplayName','Length: 25 mm');
title('Length Modifications OCV, 800 Hz');
xlabel('RMS Current (A)');
ylabel('Open-Circuit Voltage (V)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L5_Pow.I_RMS(31:40), L5_Pow.Voc_RMS(31:40), 'bo-', 'LineWidth', 2, 'DisplayName','Length: 5 mm');
hold on;
plot(L10_Pow.I_RMS(31:40), L10_Pow.Voc_RMS(31:40), 'ro-', 'LineWidth', 2, 'DisplayName','Length: 10 mm');
plot(L15_Pow.I_RMS(31:40), L15_Pow.Voc_RMS(31:40), 'ko-', 'LineWidth', 2, 'DisplayName','Length: 15 mm');
plot(L20_Pow.I_RMS(31:40), L20_Pow.Voc_RMS(31:40), 'go-', 'LineWidth', 2, 'DisplayName','Length: 20 mm');
plot(L25_Pow.I_RMS(31:40), L25_Pow.Voc_RMS(31:40), 'co-', 'LineWidth', 2, 'DisplayName','Length: 25 mm');
title('Length Modifications OCV, 1000 Hz');
xlabel('RMS Current (A)');
ylabel('Open-Circuit Voltage (V)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L5_Pow.I_RMS(1:10), L5_Pow.Power_to_Mass(1:10), 'bo-', 'LineWidth', 2, 'DisplayName','Length: 5 mm');
hold on;
plot(L10_Pow.I_RMS(1:10), L10_Pow.Power_to_Mass(1:10), 'ro-', 'LineWidth', 2, 'DisplayName','Length: 10 mm');
plot(L15_Pow.I_RMS(1:10), L15_Pow.Power_to_Mass(1:10), 'ko-', 'LineWidth', 2, 'DisplayName','Length: 15 mm');
plot(L20_Pow.I_RMS(1:10), L20_Pow.Power_to_Mass(1:10), 'go-', 'LineWidth', 2, 'DisplayName','Length: 20 mm');
plot(L25_Pow.I_RMS(1:10), L25_Pow.Power_to_Mass(1:10), 'co-', 'LineWidth', 2, 'DisplayName','Length: 25 mm');
title('Length Modifications Power-Mass Ratio, 300 Hz');
xlabel('RMS Current (A)');
ylabel('Power-Mass Ratio (W/kg)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L5_Pow.I_RMS(11:20), L5_Pow.Power_to_Mass(11:20), 'bo-', 'LineWidth', 2, 'DisplayName','Length: 5 mm');
hold on;
plot(L10_Pow.I_RMS(11:20), L10_Pow.Power_to_Mass(11:20), 'ro-', 'LineWidth', 2, 'DisplayName','Length: 10 mm');
plot(L15_Pow.I_RMS(11:20), L15_Pow.Power_to_Mass(11:20), 'ko-', 'LineWidth', 2, 'DisplayName','Length: 15 mm');
plot(L20_Pow.I_RMS(11:20), L20_Pow.Power_to_Mass(11:20), 'go-', 'LineWidth', 2, 'DisplayName','Length: 20 mm');
plot(L25_Pow.I_RMS(11:20), L25_Pow.Power_to_Mass(11:20), 'co-', 'LineWidth', 2, 'DisplayName','Length: 25 mm');
title('Length Modifications Power-Mass Ratio, 500 Hz');
xlabel('RMS Current (A)');
ylabel('Power-Mass Ratio (W/kg)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L5_Pow.I_RMS(21:30), L5_Pow.Power_to_Mass(21:30), 'bo-', 'LineWidth', 2, 'DisplayName','Length: 5 mm');
hold on;
plot(L10_Pow.I_RMS(21:30), L10_Pow.Power_to_Mass(21:30), 'ro-', 'LineWidth', 2, 'DisplayName','Length: 10 mm');
plot(L15_Pow.I_RMS(21:30), L15_Pow.Power_to_Mass(21:30), 'ko-', 'LineWidth', 2, 'DisplayName','Length: 15 mm');
plot(L20_Pow.I_RMS(21:30), L20_Pow.Power_to_Mass(21:30), 'go-', 'LineWidth', 2, 'DisplayName','Length: 20 mm');
plot(L25_Pow.I_RMS(21:30), L25_Pow.Power_to_Mass(21:30), 'co-', 'LineWidth', 2, 'DisplayName','Length: 25 mm');
title('Length Modifications Power-Mass Ratio, 800 Hz');
xlabel('RMS Current (A)');
ylabel('Power-Mass Ratio (W/kg)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L5_Pow.I_RMS(31:40), L5_Pow.Power_to_Mass(31:40), 'bo-', 'LineWidth', 2, 'DisplayName','Length: 5 mm');
hold on;
plot(L10_Pow.I_RMS(31:40), L10_Pow.Power_to_Mass(31:40), 'ro-', 'LineWidth', 2, 'DisplayName','Length: 10 mm');
plot(L15_Pow.I_RMS(31:40), L15_Pow.Power_to_Mass(31:40), 'ko-', 'LineWidth', 2, 'DisplayName','Length: 15 mm');
plot(L20_Pow.I_RMS(31:40), L20_Pow.Power_to_Mass(31:40), 'go-', 'LineWidth', 2, 'DisplayName','Length: 20 mm');
plot(L25_Pow.I_RMS(31:40), L25_Pow.Power_to_Mass(31:40), 'co-', 'LineWidth', 2, 'DisplayName','Length: 25 mm');
title('Length Modifications Power-Mass Ratio, 1000 Hz');
xlabel('RMS Current (A)');
ylabel('Power-Mass Ratio (W/kg)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L5_10_300.H_Loop, L5_10_300.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','Length: 5 mm');
hold on;
plot(L10_10_300.H_Loop, L10_10_300.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','Length: 10 mm');
plot(L15_10_300.H_Loop, L15_10_300.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','Length: 15 mm');
plot(L20_10_300.H_Loop, L20_10_300.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','Length: 20 mm');
plot(L25_10_300.H_Loop, L25_10_300.B_Loop, 'c-', 'LineWidth', 2, 'DisplayName','Length: 25 mm');
title('Length Modifications B-H Loops 10A, 300 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L5_10_500.H_Loop, L5_10_500.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','Length: 5 mm');
hold on;
plot(L10_10_500.H_Loop, L10_10_500.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','Length: 10 mm');
plot(L15_10_500.H_Loop, L15_10_500.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','Length: 15 mm');
plot(L20_10_500.H_Loop, L20_10_500.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','Length: 20 mm');
plot(L25_10_500.H_Loop, L25_10_500.B_Loop, 'c-', 'LineWidth', 2, 'DisplayName','Length: 25 mm');
title('Length Modifications B-H Loops 10A, 500 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L5_10_800.H_Loop, L5_10_800.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','Length: 5 mm');
hold on;
plot(L10_10_800.H_Loop, L10_10_800.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','Length: 10 mm');
plot(L15_10_800.H_Loop, L15_10_800.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','Length: 15 mm');
plot(L20_10_800.H_Loop, L20_10_800.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','Length: 20 mm');
plot(L25_10_800.H_Loop, L25_10_800.B_Loop, 'c-', 'LineWidth', 2, 'DisplayName','Length: 25 mm');
title('Length Modifications B-H Loops 10A, 800 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L5_10_1000.H_Loop, L5_10_1000.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','Length: 5 mm');
hold on;
plot(L10_10_1000.H_Loop, L10_10_1000.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','Length: 10 mm');
plot(L15_10_1000.H_Loop, L15_10_1000.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','Length: 15 mm');
plot(L20_10_1000.H_Loop, L20_10_1000.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','Length: 20 mm');
plot(L25_10_1000.H_Loop, L25_10_1000.B_Loop, 'c-', 'LineWidth', 2, 'DisplayName','Length: 25 mm');
title('Length Modifications B-H Loops 10A, 1000 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L5_7_300.H_Loop, L5_7_300.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','7A');
hold on;
plot(L5_8_300.H_Loop, L5_8_300.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','8A');
plot(L5_9_300.H_Loop, L5_9_300.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','9A');
plot(L5_10_300.H_Loop, L5_10_300.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','10A');
plot(L5_12_300.H_Loop, L5_12_300.B_Loop, 'c-', 'LineWidth', 2, 'DisplayName','12A');
title('Length: 5 mm Design B-H Loops at 300 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L10_7_300.H_Loop, L10_7_300.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','7A');
hold on;
plot(L10_8_300.H_Loop, L10_8_300.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','8A');
plot(L10_9_300.H_Loop, L10_9_300.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','9A');
plot(L10_10_300.H_Loop, L10_10_300.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','10A');
plot(L10_12_300.H_Loop, L10_12_300.B_Loop, 'c-', 'LineWidth', 2, 'DisplayName','12A');
title('Length: 10 mm Design B-H Loops at 300 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L15_7_300.H_Loop, L15_7_300.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','7A');
hold on;
plot(L15_8_300.H_Loop, L15_8_300.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','8A');
plot(L15_9_300.H_Loop, L15_9_300.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','9A');
plot(L15_10_300.H_Loop, L15_10_300.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','10A');
plot(L15_12_300.H_Loop, L15_12_300.B_Loop, 'c-', 'LineWidth', 2, 'DisplayName','12A');
title('Length: 15 mm Design B-H Loops at 300 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L20_7_300.H_Loop, L20_7_300.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','7A');
hold on;
plot(L20_8_300.H_Loop, L20_8_300.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','8A');
plot(L20_9_300.H_Loop, L20_9_300.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','9A');
plot(L20_10_300.H_Loop, L20_10_300.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','10A');
plot(L20_12_300.H_Loop, L20_12_300.B_Loop, 'c-', 'LineWidth', 2, 'DisplayName','12A');
title('Length: 20 mm Design B-H Loops at 300 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L25_7_300.H_Loop, L25_7_300.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','7A');
hold on;
plot(L25_8_300.H_Loop, L25_8_300.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','8A');
plot(L25_9_300.H_Loop, L25_9_300.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','9A');
plot(L25_10_300.H_Loop, L25_10_300.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','10A');
plot(L25_12_300.H_Loop, L25_12_300.B_Loop, 'c-', 'LineWidth', 2, 'DisplayName','12A');
title('Length: 25 mm Design B-H Loops at 300 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% GRAPH SQUAD: MATERIAL

figure;
plot(L10_Pow.I_RMS(1:10), L10_Pow.Voc_RMS(1:10), 'bo-', 'LineWidth', 2, 'DisplayName','Base Design');
hold on;
plot(Moulded_Basic_Pow.I_RMS(1:10), Moulded_Basic_Pow.Voc_RMS(1:10), 'ro-', 'LineWidth', 2, 'DisplayName','Moulded');
plot(MIT_Basic_Pow.I_RMS(1:10), MIT_Basic_Pow.Voc_RMS(1:10), 'ko-', 'LineWidth', 2, 'DisplayName','MIT');
plot(MnZn_Basic_Pow.I_RMS(1:10), MnZn_Basic_Pow.Voc_RMS(1:10), 'go-', 'LineWidth', 2, 'DisplayName','MnZn');
title('Material Modifications OCV, 300 Hz');
xlabel('RMS Current (A)');
ylabel('Open-Circuit Voltage (V)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L10_Pow.I_RMS(11:20), L10_Pow.Voc_RMS(11:20), 'bo-', 'LineWidth', 2, 'DisplayName','Base Design');
hold on;
plot(Moulded_Basic_Pow.I_RMS(11:20), Moulded_Basic_Pow.Voc_RMS(11:20), 'ro-', 'LineWidth', 2, 'DisplayName','Moulded');
plot(MIT_Basic_Pow.I_RMS(11:20), MIT_Basic_Pow.Voc_RMS(11:20), 'ko-', 'LineWidth', 2, 'DisplayName','MIT');
plot(MnZn_Basic_Pow.I_RMS(11:20), MnZn_Basic_Pow.Voc_RMS(11:20), 'go-', 'LineWidth', 2, 'DisplayName','MnZn');
title('Material Modifications OCV, 500 Hz');
xlabel('RMS Current (A)');
ylabel('Open-Circuit Voltage (V)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L10_Pow.I_RMS(21:30), L10_Pow.Voc_RMS(21:30), 'bo-', 'LineWidth', 2, 'DisplayName','Base Design');
hold on;
plot(Moulded_Basic_Pow.I_RMS(21:30), Moulded_Basic_Pow.Voc_RMS(21:30), 'ro-', 'LineWidth', 2, 'DisplayName','Moulded');
plot(MIT_Basic_Pow.I_RMS(21:30), MIT_Basic_Pow.Voc_RMS(21:30), 'ko-', 'LineWidth', 2, 'DisplayName','MIT');
plot(MnZn_Basic_Pow.I_RMS(21:30), MnZn_Basic_Pow.Voc_RMS(21:30), 'go-', 'LineWidth', 2, 'DisplayName','MnZn');
title('Material Modifications OCV, 800 Hz');
xlabel('RMS Current (A)');
ylabel('Open-Circuit Voltage (V)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L10_Pow.I_RMS(31:40), L10_Pow.Voc_RMS(31:40), 'bo-', 'LineWidth', 2, 'DisplayName','Base Design');
hold on;
plot(Moulded_Basic_Pow.I_RMS(31:40), Moulded_Basic_Pow.Voc_RMS(31:40), 'ro-', 'LineWidth', 2, 'DisplayName','Moulded');
plot(MIT_Basic_Pow.I_RMS(31:40), MIT_Basic_Pow.Voc_RMS(31:40), 'ko-', 'LineWidth', 2, 'DisplayName','MIT');
plot(MnZn_Basic_Pow.I_RMS(31:40), MnZn_Basic_Pow.Voc_RMS(31:40), 'go-', 'LineWidth', 2, 'DisplayName','MnZn');
title('Material Modifications OCV, 1000 Hz');
xlabel('RMS Current (A)');
ylabel('Open-Circuit Voltage (V)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L10_Pow.I_RMS(1:10), L10_Pow.Power_to_Mass(1:10), 'bo-', 'LineWidth', 2, 'DisplayName','Base Design');
hold on;
plot(Moulded_Basic_Pow.I_RMS(1:10), Moulded_Basic_Pow.Power_to_Mass(1:10), 'ro-', 'LineWidth', 2, 'DisplayName','Moulded');
plot(MIT_Basic_Pow.I_RMS(1:10), MIT_Basic_Pow.Power_to_Mass(1:10), 'ko-', 'LineWidth', 2, 'DisplayName','MIT');
plot(MnZn_Basic_Pow.I_RMS(1:10), MnZn_Basic_Pow.Power_to_Mass(1:10), 'go-', 'LineWidth', 2, 'DisplayName','MnZn');
title('Material Modifications Power-Mass Ratio, 300 Hz');
xlabel('RMS Current (A)');
ylabel('Power-Mass Ratio (W/kg)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L10_Pow.I_RMS(11:20), L10_Pow.Power_to_Mass(11:20), 'bo-', 'LineWidth', 2, 'DisplayName','Base Design');
hold on;
plot(Moulded_Basic_Pow.I_RMS(11:20), Moulded_Basic_Pow.Power_to_Mass(11:20), 'ro-', 'LineWidth', 2, 'DisplayName','Moulded');
plot(MIT_Basic_Pow.I_RMS(11:20), MIT_Basic_Pow.Power_to_Mass(11:20), 'ko-', 'LineWidth', 2, 'DisplayName','MIT');
plot(MnZn_Basic_Pow.I_RMS(11:20), MnZn_Basic_Pow.Power_to_Mass(11:20), 'go-', 'LineWidth', 2, 'DisplayName','MnZn');
title('Material Modifications Power-Mass Ratio, 500 Hz');
xlabel('RMS Current (A)');
ylabel('Power-Mass Ratio (W/kg)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L10_Pow.I_RMS(21:30), L10_Pow.Power_to_Mass(21:30), 'bo-', 'LineWidth', 2, 'DisplayName','Base Design');
hold on;
plot(Moulded_Basic_Pow.I_RMS(21:30), Moulded_Basic_Pow.Power_to_Mass(21:30), 'ro-', 'LineWidth', 2, 'DisplayName','Moulded');
plot(MIT_Basic_Pow.I_RMS(21:30), MIT_Basic_Pow.Power_to_Mass(21:30), 'ko-', 'LineWidth', 2, 'DisplayName','MIT');
plot(MnZn_Basic_Pow.I_RMS(21:30), MnZn_Basic_Pow.Power_to_Mass(21:30), 'go-', 'LineWidth', 2, 'DisplayName','MnZn');
title('Material Modifications Power-Mass Ratio, 800 Hz');
xlabel('RMS Current (A)');
ylabel('Power-Mass Ratio (W/kg)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L10_Pow.I_RMS(31:40), L10_Pow.Power_to_Mass(31:40), 'bo-', 'LineWidth', 2, 'DisplayName','Base Design');
hold on;
plot(Moulded_Basic_Pow.I_RMS(31:40), Moulded_Basic_Pow.Power_to_Mass(31:40), 'ro-', 'LineWidth', 2, 'DisplayName','Moulded');
plot(MIT_Basic_Pow.I_RMS(31:40), MIT_Basic_Pow.Power_to_Mass(31:40), 'ko-', 'LineWidth', 2, 'DisplayName','MIT');
plot(MnZn_Basic_Pow.I_RMS(31:40), MnZn_Basic_Pow.Power_to_Mass(31:40), 'go-', 'LineWidth', 2, 'DisplayName','MnZn');
title('Material Modifications Power-Mass Ratio, 1000 Hz');
xlabel('RMS Current (A)');
ylabel('Power-Mass Ratio (W/kg)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L10_10_300.H_Loop, L10_10_300.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','Base Design');
hold on;
plot(Moulded_Basic_10_300.H_Loop, Moulded_Basic_10_300.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','Moulded');
plot(MIT_Basic_10_300.H_Loop, MIT_Basic_10_300.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','MIT');
plot(MnZn_Basic_10_300.H_Loop, MnZn_Basic_10_300.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','MnZn');
title('Material Modifications B-H Loops 10A, 300 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L10_10_500.H_Loop, L10_10_500.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','Base Design');
hold on;
plot(Moulded_Basic_10_500.H_Loop, Moulded_Basic_10_500.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','Moulded');
plot(MIT_Basic_10_500.H_Loop, MIT_Basic_10_500.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','MIT');
plot(MnZn_Basic_10_500.H_Loop, MnZn_Basic_10_500.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','MnZn');
title('Material Modifications B-H Loops 10A, 500 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L10_10_800.H_Loop, L10_10_800.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','Base Design');
hold on;
plot(Moulded_Basic_10_800.H_Loop, Moulded_Basic_10_800.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','Moulded');
plot(MIT_Basic_10_800.H_Loop, MIT_Basic_10_800.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','MIT');
plot(MnZn_Basic_10_800.H_Loop, MnZn_Basic_10_800.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','MnZn');
title('Material Modifications B-H Loops 10A, 800 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L10_10_1000.H_Loop, L10_10_1000.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','Base Design');
hold on;
plot(Moulded_Basic_10_1000.H_Loop, Moulded_Basic_10_1000.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','Moulded');
plot(MIT_Basic_10_1000.H_Loop, MIT_Basic_10_1000.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','MIT');
plot(MnZn_Basic_10_1000.H_Loop, MnZn_Basic_10_1000.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','MnZn');
title('Material Modifications B-H Loops 10A, 1000 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L10_7_300.H_Loop, L10_7_300.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','7A');
hold on;
plot(L10_8_300.H_Loop, L10_8_300.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','8A');
plot(L10_9_300.H_Loop, L10_9_300.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','9A');
plot(L10_10_300.H_Loop, L10_10_300.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','10A');
plot(L10_12_300.H_Loop, L10_12_300.B_Loop, 'c-', 'LineWidth', 2, 'DisplayName','12A');
title('Base Design B-H Loops at 300 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(Moulded_Basic_7_300.H_Loop, Moulded_Basic_7_300.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','7A');
hold on;
plot(Moulded_Basic_8_300.H_Loop, Moulded_Basic_8_300.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','8A');
plot(Moulded_Basic_9_300.H_Loop, Moulded_Basic_9_300.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','9A');
plot(Moulded_Basic_10_300.H_Loop, Moulded_Basic_10_300.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','10A');
plot(Moulded_Basic_12_300.H_Loop, Moulded_Basic_12_300.B_Loop, 'c-', 'LineWidth', 2, 'DisplayName','12A');
title('Moulded B-H Loops at 300 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(MnZn_Basic_7_300.H_Loop, MnZn_Basic_7_300.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','7A');
hold on;
plot(MnZn_Basic_8_300.H_Loop, MnZn_Basic_8_300.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','8A');
plot(MnZn_Basic_9_300.H_Loop, MnZn_Basic_9_300.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','9A');
plot(MnZn_Basic_10_300.H_Loop, MnZn_Basic_10_300.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','10A');
plot(MnZn_Basic_12_300.H_Loop, MnZn_Basic_12_300.B_Loop, 'c-', 'LineWidth', 2, 'DisplayName','12A');
title('MnZn B-H Loops at 300 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(MIT_Basic_7_300.H_Loop, MIT_Basic_7_300.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','7A');
hold on;
plot(MIT_Basic_8_300.H_Loop, MIT_Basic_8_300.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','8A');
plot(MIT_Basic_9_300.H_Loop, MIT_Basic_9_300.B_Loop, 'k-', 'LineWidth', 2, 'DisplayName','9A');
plot(MIT_Basic_10_300.H_Loop, MIT_Basic_10_300.B_Loop, 'g-', 'LineWidth', 2, 'DisplayName','10A');
plot(MIT_Basic_12_300.H_Loop, MIT_Basic_12_300.B_Loop, 'c-', 'LineWidth', 2, 'DisplayName','12A');
title('MIT B-H Loops at 300 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% GRAPH SQUAD: PP TEMP

figure;
plot(L10_Pow.I_RMS(1:10), L10_Pow.Voc_RMS(1:10), 'bo-', 'LineWidth', 2, 'DisplayName','Protopasta 23.5 C');
hold on;
plot(PP_30C_Pow.I_RMS(1:10), PP_30C_Pow.Voc_RMS(1:10), 'ro-', 'LineWidth', 2, 'DisplayName','Protopasta 30 C');
title('Protopasta Temperature Effects on OCV, 300 Hz');
xlabel('RMS Current (A)');
ylabel('Open-Circuit Voltage (V)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(L10_10_300.H_Loop, L10_10_300.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','23.5 C');
hold on;
plot(PP_30C_10_300.H_Loop, PP_30C_10_300.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','30 C');
title('Protopasta Temperature Effects on B-H Loops at 10A, 300 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% GRAPH SQUAD: MOULDED TEMP

figure;
plot(Moulded_Basic_Pow.I_RMS(1:10), Moulded_Basic_Pow.Voc_RMS(1:10), 'bo-', 'LineWidth', 2, 'DisplayName','Moulded 23.5 C');
hold on;
plot(Moulded_30C_Pow.I_RMS(1:10), Moulded_30C_Pow.Voc_RMS(1:10), 'ro-', 'LineWidth', 2, 'DisplayName','Moulded 30 C');
title('Moulded Temperature Effects on OCV, 300 Hz');
xlabel('RMS Current (A)');
ylabel('Open-Circuit Voltage (V)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(Moulded_Basic_10_300.H_Loop, Moulded_Basic_10_300.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','23.5 C');
hold on;
plot(Moulded_30C_10_300.H_Loop, Moulded_30C_10_300.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','30 C');
title('Moulded Temperature Effects on B-H Loops at 10A, 300 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% GRAPH SQUAD: MIT TEMP

figure;
plot(MIT_Basic_Pow.I_RMS(1:10), MIT_Basic_Pow.Voc_RMS(1:10), 'bo-', 'LineWidth', 2, 'DisplayName','MIT 23.5 C');
hold on;
plot(MIT_30C_Pow.I_RMS(1:10), MIT_30C_Pow.Voc_RMS(1:10), 'ro-', 'LineWidth', 2, 'DisplayName','MIT 30 C');
title('MIT Temperature Effects on OCV, 300 Hz');
xlabel('RMS Current (A)');
ylabel('Open-Circuit Voltage (V)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(MIT_Basic_10_300.H_Loop, MIT_Basic_10_300.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','23.5 C');
hold on;
plot(MIT_30C_10_300.H_Loop, MIT_30C_10_300.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','30 C');
title('MIT Temperature Effects on B-H Loops at 10A, 300 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% GRAPH SQUAD: MnZn TEMP

figure;
plot(MnZn_Basic_Pow.I_RMS(1:10), MnZn_Basic_Pow.Voc_RMS(1:10), 'bo-', 'LineWidth', 2, 'DisplayName','MnZn 23.5 C');
hold on;
plot(MnZn_30C_Pow.I_RMS(1:10), MnZn_30C_Pow.Voc_RMS(1:10), 'ro-', 'LineWidth', 2, 'DisplayName','MnZn 30 C');
title('MnZn Temperature Effects on OCV, 300 Hz');
xlabel('RMS Current (A)');
ylabel('Open-Circuit Voltage (V)');
grid on;
hold off;
legend('Location','northwest');

figure;
plot(MnZn_Basic_10_300.H_Loop, MnZn_Basic_10_300.B_Loop, 'b-', 'LineWidth', 2, 'DisplayName','23.5 C');
hold on;
plot(MnZn_30C_10_300.H_Loop, MnZn_30C_10_300.B_Loop, 'r-', 'LineWidth', 2, 'DisplayName','30 C');
title('MnZn Temperature Effects on B-H Loops at 10A, 300 Hz');
xlabel('H (A/m)');
ylabel('B (T)');
grid on;
hold off;
legend('Location','northwest');