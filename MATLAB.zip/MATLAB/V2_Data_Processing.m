% WARNING - Do NOT process data from more than one core at a time

% WARNING - Missing cells in columns are treated as NaN when column is read

% IMPORTANT - Make sure that, for hysteresis measurements, that the .xlsx
% files all have the same channel for current and the same channel for
% voltage (you can specify which channel number is current or voltage
% below, but consistency is needed to avoided the wrong quantity being
% integrated)

% STEP 1: Use copies of the given .xlsx template files to record raw
% results as appropriate. 

% STEP 2: Store all raw result files in their appropriate processing
% folders ('Power' for V_oc and matched power calculations and graphs, and 
% 'Hysteresis' for any B-H calculations and graphs).

% STEP 3: Rename columns in power file to 'Voc_RMS', 'Rs', 'Matched_Power',
% 'Coiled_Mass', 'I_RMS', 'Done', 'Power_to_Mass'.

% STEP 4: Rename all .csv files appropriately to the format "X.YA_Channel".

% STEP 5: Please, using ctrl+F, search 'DATA PROCESING BLOCK' and check
% each data processing block in this script. Add or remove code to perform
% whatever data processing is desired.

% STEP 6: Set the parameters in the THREE set blocks below.

% STEP 7: Find the full path to the power subfolder and paste it below.

% STEP 8: Find the full path to the hysteresis subfolder and paste it 
% below (TWO PLACES).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% SET: Parameters for calculating B and H, respectively
N = 100; % Number of turns on the core (unitless)
A = 0.000025; % Cross-sectional AREA of core flux path (m^2)
Dist = (0.8 + 3.5 + 2.5)/1000;
PL = (2*pi*Dist); % Flux circulation PATH LENGTH - Constant for a given core (m)
N_int = 4; % Number of current cycles to integrate over to find DC error
N_currents = 10; % Number of current values tested for the core per freq.
Core_name = 'Fillet'; % Name of core being tested (for distinct file names)

% SET: Scope channels for line current and OC voltage (1, 2, MATH1, etc.)
I_Channel = "1";
V_Channel = "MATH1";

% SET: Frequency range of measurements, name format 'H-[FREQ_VALUE]'
Freq_range = ["H-300", "H-500", "H-800", "H-1000"];


% GOAL: One by one, reads the raw 'Power' .xlsx files and performs data
% processing on their raw data, writing in the results into empty columns

% SET: Power folder path
main_pow_folder = "C:\Users\gtetr\Desktop\Gabriel Tetrault - Final Year Project\Data\[PROCESSED] Data\Experiment 1\Filleted OCV + Hysteresis\Power";

% Choose .xlsx files or .csv files to process - comment out the other
%Pow_dir = fullfile(main_pow_folder, "*.csv");
Pow_dir = fullfile(main_pow_folder, "*.xlsx");


Pow_files = dir(char(Pow_dir));

if isempty(Pow_files)
    warning("No files found in %s", main_pow_folder);
end

%%%%%%%%%%%%%%%%

for i = 1:length(Pow_files)
    % This assigns a distinct file name to each raw data file
    Pow_filename = fullfile(Pow_files(i).folder, Pow_files(i).name);
    
    % Creates a table that has all contents of the current raw data file
    Pow_table = readtable(Pow_filename);

    goAhead = 1;

    if all(ismember('Done', Pow_table.Properties.VariableNames)) == false
        Pow_table.Done(1) = 0;
    end

    if Pow_table.Done(1) == 1
        Overwrite_Prompt = append("File ", Pow_files(i).name, ...
            " is already processed. Proceed and risk overwrite [Y/N]?");

        Overwrite_Check = input(Overwrite_Prompt,"s");

        if isempty(Overwrite_Check)
            txt = "Y";
        end

        if Overwrite_Check == "Y"
            goAhead = 1;
        end

        if Overwrite_Check == "y"
            goAhead = 1;
        end

        if Overwrite_Check == "N"
            goAhead = 0;
        end

        if Overwrite_Check == "n"
            goAhead = 0;
        end

    end

    if goAhead == 1

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % DATA PROCESSING BLOCK 1: PLEASE DEFINE ALL DESIRED PROCESSING HERE

    Pow_table.Matched_Power = (Pow_table.Voc_RMS).^2/(0.001*4*Pow_table.Rs(1));

    Pow_table.Power_to_Mass = Pow_table.Matched_Power./Pow_table.Coiled_Mass(1);

    I_300 = Pow_table.I_RMS(1:N_currents);
    V_300 = Pow_table.Voc_RMS(1:N_currents);
    [I_300_sorted, Idx_300] = sort(I_300);
    V_300_sorted = V_300(Idx_300);
    Name_300 = "Open-Circuit Voltage of " + Core_name + " at 300 Hz";

    I_500 = Pow_table.I_RMS((N_currents + 1):(2*N_currents));
    V_500 = Pow_table.Voc_RMS((N_currents + 1):(2*N_currents));
    [I_500_sorted, Idx_500] = sort(I_500);
    V_500_sorted = V_500(Idx_500);
    Name_500 = "Open-Circuit Voltage of " + Core_name + " at 500 Hz";

    I_800 = Pow_table.I_RMS((2*N_currents + 1):(3*N_currents));
    V_800 = Pow_table.Voc_RMS((2*N_currents + 1):(3*N_currents));
    [I_800_sorted, Idx_800] = sort(I_800);
    V_800_sorted = V_800(Idx_800);
    Name_800 = "Open-Circuit Voltage of " + Core_name + " at 800 Hz";

    I_1000 = Pow_table.I_RMS((3*N_currents + 1):(4*N_currents));
    V_1000 = Pow_table.Voc_RMS((3*N_currents + 1):(4*N_currents));
    [I_1000_sorted, Idx_1000] = sort(I_1000);
    V_1000_sorted = V_1000(Idx_1000);
    Name_1000 = "Open-Circuit Voltage of " + Core_name + " at 1000 Hz";

    figure;
    plot(I_300_sorted, V_300_sorted, 'LineWidth', 2);
    title(Name_300);
    xlabel('RMS Current (A)');
    ylabel('Open-Circuit Voltage (V)');
    grid on;

    figure;
    plot(I_500_sorted, V_500_sorted, 'LineWidth', 2);
    title(Name_500);
    xlabel('RMS Current (A)');
    ylabel('Open-Circuit Voltage (V)');
    grid on;

    figure;
    plot(I_800_sorted, V_800_sorted, 'LineWidth', 2);
    title(Name_800);
    xlabel('RMS Current (A)');
    ylabel('Open-Circuit Voltage (V)');
    grid on;

    figure;
    plot(I_1000_sorted, V_1000_sorted, 'LineWidth', 2);
    title(Name_1000);
    xlabel('RMS Current (A)');
    ylabel('Open-Circuit Voltage (V)');
    grid on;

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    end

    Pow_table.Done(1) = 1;

    writetable(Pow_table, Pow_filename);
        
    fprintf("Updated file: %s\n", Pow_files(i).name);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% SET: Frequency range of measurements, name format 'H-[FREQ_VALUE]'
Freq_range = ["H-300", "H-500", "H-800", "H-1000"];

% GOAL: One by one, reads the raw 'Hysteresis' .xlsx files and performs 
% data processing on their raw data, writing in the results into empty 
% columns
for j = 1:length(Freq_range)
    % SET: Hysteresis folder path, and subfolders for B-H tables/graphs
    main_hys_folder = "C:\Users\gtetr\Desktop\Gabriel Tetrault - Final Year Project\Data\[PROCESSED] Data\Experiment 1\Filleted OCV + Hysteresis\Hysteresis";
    store_subfolder = fullfile(main_hys_folder, "B-H Tables");
    graph_subfolder = fullfile(main_hys_folder, "B-H Graphs");
    
    % SET: Hysteresis folder path
    folder_path = fullfile("C:\Users\gtetr\Desktop\Gabriel Tetrault - Final Year Project\Data\[PROCESSED] Data\Experiment 1\Filleted OCV + Hysteresis\Hysteresis", Freq_range(j));

    % Choose .xlsx files or .csv files to process - comment out the other
    Hys_dir = fullfile(folder_path, "*.csv");
    %Hys_dir = fullfile(folder_path, "*.xlsx");


    Hys_files = dir(char(Hys_dir));

    if isempty(Hys_files)
        warning("No files found in %s", folder_path);
        continue;
    end

    for k = 5.0:0.1:20.0

        I_Check = 0;
        V_Check = 0;

        Test_current = sprintf("%.1fA", k);
        I_Test_current = sprintf("%.1fA_" + I_Channel, k);
        V_Test_current = sprintf("%.1fA_" + V_Channel, k);

        for l = 1:length(Hys_files)

            if startsWith(Hys_files(l).name, I_Test_current)

                % This assigns a distinct file name to each raw data file
                I_Hys_filename = fullfile(Hys_files(l).folder, Hys_files(l).name);
                
                % Creates a table that has all contents of the current raw data file
                I_Hys_table = readtable(I_Hys_filename, 'NumHeaderLines', 1);
                I_Hys_table.Properties.VariableNames = ["Time", "I_Line"];
                I_Check = 1;
            end

            if startsWith(Hys_files(l).name, V_Test_current)

                % This assigns a distinct file name to each raw data file
                V_Hys_filename = fullfile(Hys_files(l).folder, Hys_files(l).name);
                
                % Creates a table that has all contents of the current raw data file
                V_Hys_table = readtable(V_Hys_filename, 'NumHeaderLines', 1);
                V_Hys_table.Properties.VariableNames = ["Time", "V_OC"];
                V_Check = 1;
            end

        end

                if (I_Check == 1) && (V_Check == 1)
                    Calc_Hys = array2table(rand(length(I_Hys_table.Time), 7));
                    Calc_Hys{:, :} = 0;
                    Calc_Hys.Properties.VariableNames{'Var1'} = 'Calc_Time';
                    Calc_Hys.Properties.VariableNames{'Var2'} = 'Calc_Current';
                    Calc_Hys.Properties.VariableNames{'Var3'} = 'Calc_Voltage';
                    Calc_Hys.Properties.VariableNames{'Var4'} = 'Calc_B';
                    Calc_Hys.Properties.VariableNames{'Var5'} = 'Calc_H';
                    Calc_Hys.Properties.VariableNames{'Var6'} = 'B_Loop';
                    Calc_Hys.Properties.VariableNames{'Var7'} = 'H_Loop';
    
                    Calc_Hys.Calc_Time = I_Hys_table.Time;


                    % SET: Back-convert from current sensor scale - 10 mV/A
                    Calc_Hys.Calc_Current = I_Hys_table.I_Line/0.01;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                
                    % Process current by finding DC error and compensating
                    Split_name = split(Freq_range(j), "-");
                    Num_freq = str2double(Split_name(2));
                    
                    for m = 1:length(Calc_Hys.Calc_Time)
                        if Calc_Hys.Calc_Time(m) >= 0
                            break;
                        end
                    end
                
                    Entry_time_diff = Calc_Hys.Calc_Time(2) - Calc_Hys.Calc_Time(1);
    
                    % Intend to integrate current across N_int full cycles
                    Num_cycle = round((1/(Num_freq*Entry_time_diff)) - 1);
                    
                    Num_to_sum = round((N_int/(Num_freq*Entry_time_diff)) - 1);
    
                    Current_time_calib = Calc_Hys.Calc_Time(m:(m + Num_to_sum));
                    Current_calib = Calc_Hys.Calc_Current(m:(m + Num_to_sum));
    
                    Current_area_error = trapz(Current_time_calib, Current_calib);
    
                    Current_comp_DC = -(Current_area_error*Num_freq)/N_int;
    
                    Calc_Hys.Calc_Current = Calc_Hys.Calc_Current + Current_comp_DC;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                    Calc_Hys.Calc_H = Calc_Hys.Calc_Current/PL;
    
                    Calc_Hys.Calc_Voltage = V_Hys_table.V_OC - mean(V_Hys_table.V_OC(m:(m + Num_to_sum)));
                    Voltage_time_calib = Calc_Hys.Calc_Time(m:(m + Num_cycle));
                    Voltage_calib = Calc_Hys.Calc_Voltage(m:(m + Num_cycle));
    
                    Calc_Hys.Calc_B(m:(m + Num_cycle)) = -(1/(N * A)) * cumtrapz(Voltage_time_calib, Voltage_calib);
    
                    Calc_Hys.Calc_B(m:(m + Num_cycle)) = Calc_Hys.Calc_B(m:(m + Num_cycle)) - mean(Calc_Hys.Calc_B(m:(m + Num_cycle)));

                    Calc_Hys.H_Loop(1:(Num_cycle + 1)) = Calc_Hys.Calc_H(m:(m + Num_cycle));
                    Calc_Hys.H_Loop(Num_cycle + 2) = H_Loop(1);

                    Calc_Hys.B_Loop(1:(Num_cycle + 1)) = Calc_Hys.Calc_B(m:(m + Num_cycle));
                    Calc_Hys.B_Loop(Num_cycle + 2) = B_Loop(1);

                    Store_file_name_csv = Core_name + "_BH_" + Test_current + "_" + Num_freq + ".csv";
                    %Store_file_name_xlsx = Core_name + "_BH_" + Test_current + "_" + Num_freq + ".xlsx";

                    filename_csv  = fullfile(store_subfolder, Store_file_name_csv);
                    %filename_xlsx = fullfile(store_subfolder, Store_file_name_xlsx);

                    writetable(Calc_Hys, filename_csv);
                    %writetable(Calc_Hys, filename_xlsx);

                    Graph_name = Core_name + " Hysteresis Loop: " + Test_current + ", " + Num_freq + " Hz";

                    figure;
                    plot(Calc_Hys.H_Loop, Calc_Hys.B_Loop, 'LineWidth', 2);
                    title(Graph_name);
                    xlabel('H (A/m)');
                    ylabel('B (T)');
                    grid on;

                    %Shortgraph = "The" + Test_current + Num_freq + "Hz";

                    %Save_graph_name = Graph_name + ".png";

                    %graph_locator = fullfile(store_subfolder, Save_graph_name);

                    %exportgraphics(gcf, Shortgraph, 'Resolution', 300);
   
                    goAhead = 1;
                
                    if all(ismember("Done", I_Hys_table.Properties.VariableNames)) == false
                        I_Hys_table.Done(1) = 0;
                    end
    
                    if all(ismember("Done", V_Hys_table.Properties.VariableNames)) == false
                        V_Hys_table.Done(1) = 0;
                    end
                
                    if (I_Hys_table.Done(1) == 1) || (V_Hys_table.Done(1) == 1)
                        Overwrite_Prompt = append("Files with current ", Test_current, ...
                            " are already processed. Proceed and risk overwrite [Y/N]?");
                
                        Overwrite_Check = input(Overwrite_Prompt,"s");
                
                        if isempty(Overwrite_Check)
                            txt = "Y";
                        end
                
                        if Overwrite_Check == "N"
                            goAhead = 0;
                        end
                
                        if Overwrite_Check == "n"
                            goAhead = 0;
                        end
                
                    end
                
                    if goAhead == 1
            
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % DATA PROCESSING BLOCK 2: PLEASE DEFINE ALL DESIRED PROCESSING HERE
            
           
            
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                    end
                
                    I_Hys_table.Done(1) = 1;
                    V_Hys_table.Done(1) = 1;
                
                    %I_Hys_filename.Done(1) = 1;
                    %V_Hys_filename.Done(1) = 1;
                        
                    fprintf("Updated file: %s\n", I_Hys_filename);
                    fprintf("Updated file: %s\n", V_Hys_filename);

                end

    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
